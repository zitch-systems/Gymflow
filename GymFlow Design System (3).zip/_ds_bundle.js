/* @ds-bundle: {"format":3,"namespace":"GymFlowDesignSystem_949597","components":[{"name":"AboutPage","sourcePath":"app/(platform)/about/page.tsx"},{"name":"FeaturesPage","sourcePath":"app/(platform)/features/page.tsx"},{"name":"HomePage","sourcePath":"app/(platform)/page.tsx"},{"name":"PricingPage","sourcePath":"app/(platform)/pricing/page.tsx"},{"name":"AdminShell","sourcePath":"app/gym/[slug]/admin/admin-shell.tsx"},{"name":"MarketingFooter","sourcePath":"components/marketing/footer.tsx"},{"name":"MarketingNav","sourcePath":"components/marketing/nav.tsx"},{"name":"FeatureCard","sourcePath":"components/marketing/sections.tsx"},{"name":"Step","sourcePath":"components/marketing/sections.tsx"},{"name":"Testimonial","sourcePath":"components/marketing/sections.tsx"},{"name":"Faq","sourcePath":"components/marketing/sections.tsx"}],"sourceHashes":{"app/(platform)/about/metadata.ts":"0b6219aec3f3","app/(platform)/about/page.tsx":"607f3f77c417","app/(platform)/features/metadata.ts":"73c774b9e913","app/(platform)/features/page.tsx":"38e3cf07e442","app/(platform)/page.tsx":"0fd1a625d065","app/(platform)/pricing/metadata.ts":"5930fc5a8eb2","app/(platform)/pricing/page.tsx":"2c043e89137f","app/gym/[slug]/admin/admin-shell.tsx":"a1e5a7272843","components/marketing/footer.tsx":"8afae729fc0e","components/marketing/nav.tsx":"a1b5570a0e81","components/marketing/sections.tsx":"0db5ef1adea1","revamp/admin-shell.js":"1c96a5d60b92","revamp/instructor-shell.js":"088b73ec0a96","revamp/member.js":"4f391b0cce77","revamp/mobile.js":"a5682a82b7c9","revamp/notifications-panel.js":"8ad9cd3aa99b","revamp/proto.js":"3be7433e3290","revamp/superadmin-shell.js":"a79d0fb5a779","revamp/theme.js":"580cf83470d8","revamp/ui.js":"ad08fed52e35","revamp/wire.js":"31301efc2a29"},"inlinedExternals":[],"unexposedExports":[{"name":"aboutMetadata","sourcePath":"app/(platform)/about/metadata.ts"},{"name":"featuresMetadata","sourcePath":"app/(platform)/features/metadata.ts"},{"name":"metadata","sourcePath":"app/(platform)/page.tsx"},{"name":"pricingMetadata","sourcePath":"app/(platform)/pricing/metadata.ts"}]} */

(() => {

const __ds_ns = (window.GymFlowDesignSystem_949597 = window.GymFlowDesignSystem_949597 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// app/(platform)/about/metadata.ts
try { (() => {
const aboutMetadata = {
  title: 'About & Gallery',
  description: 'GymFlow is built in Lagos for Nigerian fitness businesses — a look at who we are and the gyms that run on the platform.'
};
Object.assign(__ds_scope, { aboutMetadata });
})(); } catch (e) { __ds_ns.__errors.push({ path: "app/(platform)/about/metadata.ts", error: String((e && e.message) || e) }); }

// app/(platform)/about/page.tsx
try { (() => {
const GALLERY = [{
  src: '/images/gym-studio.jpg',
  alt: 'Cardio studio'
}, {
  src: '/images/gym-machines.jpg',
  alt: 'Resistance machines'
}, {
  src: '/images/gym-bikes.jpg',
  alt: 'Indoor cycling'
}, {
  src: '/images/gym-kettlebells.jpg',
  alt: 'Kettlebell rack'
}, {
  src: '/images/gym-barbell.jpg',
  alt: 'Barbell platform'
}, {
  src: '/images/gym-dumbbells.jpg',
  alt: 'Dumbbell wall'
}, {
  src: '/images/gym-floor.jpg',
  alt: 'Main training floor'
}, {
  src: '/images/gym-hero.jpg',
  alt: 'Members training'
}];
function AboutPage() {
  return /*#__PURE__*/React.createElement("div", {
    className: "marketing"
  }, /*#__PURE__*/React.createElement(MarketingNav, null), /*#__PURE__*/React.createElement("main", {
    id: "main-content",
    tabIndex: -1
  }, /*#__PURE__*/React.createElement("header", {
    className: "marketing-hero mk-subhero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("span", {
    className: "marketing-eyebrow"
  }, "Our story"), /*#__PURE__*/React.createElement("h1", {
    className: "marketing-hero-title"
  }, "Built in Lagos, for the gyms that ", /*#__PURE__*/React.createElement("span", {
    className: "marketing-accent"
  }, "built us")), /*#__PURE__*/React.createElement("p", {
    className: "marketing-hero-sub"
  }, "GymFlow began on a whiteboard in a Yaba co-working space \u2014 three friends frustrated that running a great gym meant drowning in spreadsheets, missed renewals and manual WhatsApp reminders. Today, hundreds of gyms across Nigeria run on it."))), /*#__PURE__*/React.createElement("section", {
    className: "marketing-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "marketing-section-title"
  }, "What we believe"), /*#__PURE__*/React.createElement("p", {
    className: "marketing-section-sub"
  }, "The principles behind every release."), /*#__PURE__*/React.createElement("div", {
    className: "marketing-grid"
  }, /*#__PURE__*/React.createElement(FeatureCard, {
    icon: HeartHandshake,
    title: "Built for operators",
    body: "Every feature starts with a real gym owner's day \u2014 not a spreadsheet of abstractions."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: Gauge,
    title: "Fast on any network",
    body: "A light, mobile-first PWA that loads quickly on 3G and works offline at the door."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: ShieldCheck,
    title: "Your data, isolated",
    body: "Row-level security per tenant. No gym can ever see another gym's members or money."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: MapPin,
    title: "Made for Naira",
    body: "Paystack-native pricing, auto-debit and payouts \u2014 no FX, no workarounds."
  })))), /*#__PURE__*/React.createElement("section", {
    className: "marketing-section mk-gallery-strip"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "marketing-section-title"
  }, "The gyms that run on GymFlow"), /*#__PURE__*/React.createElement("p", {
    className: "marketing-section-sub"
  }, "From boutique studios to multi-floor facilities \u2014 a look inside the spaces our software keeps moving every day."), /*#__PURE__*/React.createElement("div", {
    className: "mk-gallery"
  }, GALLERY.map(g => /*#__PURE__*/React.createElement("div", {
    key: g.src,
    className: "mk-gallery-item"
  }, /*#__PURE__*/React.createElement(Image, {
    src: g.src,
    alt: g.alt,
    width: 600,
    height: 800,
    loading: "lazy",
    sizes: "(max-width: 760px) 50vw, 25vw"
  })))))), /*#__PURE__*/React.createElement("section", {
    className: "marketing-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mk-cta"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "mk-cta-title"
  }, "Join the gyms growing with GymFlow"), /*#__PURE__*/React.createElement("p", {
    className: "mk-cta-sub"
  }, "Launch your branded instance in an afternoon."), /*#__PURE__*/React.createElement("div", {
    className: "marketing-hero-actions",
    style: {
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Link, {
    href: "/signup",
    className: "gf-btn gf-btn-primary gf-btn-lg"
  }, "Launch your gym"), /*#__PURE__*/React.createElement(Link, {
    href: "/features",
    className: "gf-btn gf-btn-outline gf-btn-lg"
  }, "See features")))))), /*#__PURE__*/React.createElement(MarketingFooter, null));
}
Object.assign(__ds_scope, { metadata: __ds_scope.aboutMetadata, AboutPage });
})(); } catch (e) { __ds_ns.__errors.push({ path: "app/(platform)/about/page.tsx", error: String((e && e.message) || e) }); }

// app/(platform)/features/metadata.ts
try { (() => {
const featuresMetadata = {
  title: 'Features',
  description: 'Check-in, Paystack subscriptions, classes, staff, analytics, and automation — everything a Nigerian gym needs.'
};
Object.assign(__ds_scope, { featuresMetadata });
})(); } catch (e) { __ds_ns.__errors.push({ path: "app/(platform)/features/metadata.ts", error: String((e && e.message) || e) }); }

// app/(platform)/features/page.tsx
try { (() => {
function FeatureRow({
  eyebrow,
  title,
  body,
  points,
  img,
  alt,
  reverse
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: `mk-feature-row${reverse ? ' reverse' : ''}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "mk-feature-row-media"
  }, /*#__PURE__*/React.createElement(Image, {
    src: img,
    alt: alt,
    width: 1080,
    height: 720,
    sizes: "(max-width: 768px) 100vw, 50vw",
    loading: "lazy",
    style: {
      width: '100%',
      height: 'auto'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "mk-feature-row-copy"
  }, /*#__PURE__*/React.createElement("span", {
    className: "marketing-eyebrow"
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    className: "marketing-section-title",
    style: {
      textAlign: 'left'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    className: "marketing-section-sub",
    style: {
      textAlign: 'left',
      margin: '12px 0 18px'
    }
  }, body), /*#__PURE__*/React.createElement("ul", {
    className: "mk-checklist"
  }, points.map(p => /*#__PURE__*/React.createElement("li", {
    key: p
  }, /*#__PURE__*/React.createElement(Check, {
    size: 16,
    strokeWidth: 2.5
  }), " ", p)))));
}
function FeaturesPage() {
  return /*#__PURE__*/React.createElement("div", {
    className: "marketing"
  }, /*#__PURE__*/React.createElement(MarketingNav, null), /*#__PURE__*/React.createElement("main", {
    id: "main-content",
    tabIndex: -1
  }, /*#__PURE__*/React.createElement("header", {
    className: "marketing-hero mk-subhero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("span", {
    className: "marketing-eyebrow"
  }, "Features"), /*#__PURE__*/React.createElement("h1", {
    className: "marketing-hero-title"
  }, "Everything to run and grow your gym"), /*#__PURE__*/React.createElement("p", {
    className: "marketing-hero-sub"
  }, "One platform for members, payments, classes, staff, and the back office \u2014 built mobile-first for Nigeria."), /*#__PURE__*/React.createElement("div", {
    className: "marketing-hero-actions"
  }, /*#__PURE__*/React.createElement(Link, {
    href: "/signup",
    className: "gf-btn gf-btn-primary gf-btn-lg"
  }, "Launch your gym"), /*#__PURE__*/React.createElement(Link, {
    href: "/pricing",
    className: "gf-btn gf-btn-outline gf-btn-lg"
  }, "See pricing")))), /*#__PURE__*/React.createElement("section", {
    className: "marketing-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "marketing-grid"
  }, /*#__PURE__*/React.createElement(FeatureCard, {
    icon: ScanLine,
    title: "QR check-in",
    body: "Members scan a static entrance code from the PWA. Attendance logs live; works offline."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: CreditCard,
    title: "Paystack subscriptions",
    body: "Card & transfer in Naira, tokenised cards, auto-renew with smart retries."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: CalendarDays,
    title: "Classes & booking",
    body: "Recurring timetable, capacity caps, waitlists with auto-promotion."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: Users,
    title: "Staff & roles",
    body: "Owner, manager, front desk, accountant, instructor \u2014 scoped access for each."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: GraduationCap,
    title: "Instructor portal",
    body: "Coaches manage clients, sessions, earnings and payouts from their phone."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: BarChart3,
    title: "Analytics & reports",
    body: "Revenue, churn, attendance, P&L \u2014 live, with CSV/PDF export."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: Bell,
    title: "Automated reminders",
    body: "Expiry nudges at 7/3/1 days on WhatsApp + email. Receipts on every payment."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: Wallet,
    title: "Wallet & payments",
    body: "Real-time balance, full transaction history, manual cash entry."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: Wrench,
    title: "Equipment & expenses",
    body: "Track inventory, maintenance schedules, and a daily expense ledger."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: FileText,
    title: "Digital waiver",
    body: "Versioned waiver with timestamped signatures captured at signup."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: Smartphone,
    title: "Installable PWA",
    body: "Branded member & coach apps \u2014 add to home screen on Android & iOS."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: ClipboardList,
    title: "Self-service onboarding",
    body: "Members sign up, pay, and get a membership in minutes \u2014 no front-desk queue."
  })))), /*#__PURE__*/React.createElement("section", {
    className: "marketing-section mk-rows"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement(FeatureRow, {
    eyebrow: "For members",
    title: "A branded app your members actually use",
    body: "Members check in by QR, see days remaining, renew in a tap, browse classes, and book a spot \u2014 all from a fast PWA that installs to their home screen.",
    points: ['QR check-in with instant access feedback', 'Renew & pay ahead via Paystack', 'Book classes with live capacity & waitlists', 'Streaks, activity, and next-class at a glance'],
    img: "/images/gym-studio.jpg",
    alt: "Cardio studio"
  }), /*#__PURE__*/React.createElement(FeatureRow, {
    reverse: true,
    eyebrow: "For owners",
    title: "The back office, on autopilot",
    body: "Auto-debit renewals, dunning, expiry reminders, and live analytics mean less admin and more retained members \u2014 money settles straight to your Paystack subaccount.",
    points: ['Auto-debit with retries & grace periods', 'Expiry reminders on WhatsApp + email', 'Revenue, churn & attendance dashboards', 'Equipment, expenses, P&L and exports'],
    img: "/images/gym-floor.jpg",
    alt: "Gym floor with machines"
  }), /*#__PURE__*/React.createElement(FeatureRow, {
    eyebrow: "For coaches",
    title: "A portal built for instructors",
    body: "Coaches manage their clients, schedule and mark sessions, track earnings with revenue share, and request payouts \u2014 capped to what they've actually earned.",
    points: ['Client list & session attendance', 'Class timetable & bookings', 'Earnings with revenue-share tracking', 'Self-service payout requests'],
    img: "/images/gym-dumbbells.jpg",
    alt: "Dumbbell rack"
  }))), /*#__PURE__*/React.createElement("section", {
    className: "marketing-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mk-cta"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "mk-cta-title"
  }, "See it running for your gym"), /*#__PURE__*/React.createElement("p", {
    className: "mk-cta-sub"
  }, "Spin up your branded instance in minutes."), /*#__PURE__*/React.createElement("div", {
    className: "marketing-hero-actions",
    style: {
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Link, {
    href: "/signup",
    className: "gf-btn gf-btn-primary gf-btn-lg"
  }, "Launch your gym")))))), /*#__PURE__*/React.createElement(MarketingFooter, null));
}
Object.assign(__ds_scope, { metadata: __ds_scope.featuresMetadata, FeaturesPage });
})(); } catch (e) { __ds_ns.__errors.push({ path: "app/(platform)/features/page.tsx", error: String((e && e.message) || e) }); }

// app/(platform)/page.tsx
try { (() => {
const metadata = {
  title: 'GymFlow — Run your gym the modern way',
  description: 'Check-ins, Paystack subscriptions, class booking and automated reminders — one mobile-first platform built for Nigerian gyms.'
};
const GALLERY = [{
  src: '/images/gym-bikes.jpg',
  alt: 'Indoor cycling studio'
}, {
  src: '/images/gym-machines.jpg',
  alt: 'Resistance machines'
}, {
  src: '/images/gym-kettlebells.jpg',
  alt: 'Kettlebell rack'
}, {
  src: '/images/gym-barbell.jpg',
  alt: 'Barbell training area'
}];
function HomePage() {
  return /*#__PURE__*/React.createElement("div", {
    className: "marketing"
  }, /*#__PURE__*/React.createElement(MarketingNav, null), /*#__PURE__*/React.createElement("main", {
    id: "main-content",
    tabIndex: -1
  }, /*#__PURE__*/React.createElement("header", {
    className: "marketing-hero mk-hero-photo"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mk-hero-photo-bg",
    style: {
      backgroundImage: 'url(/images/gym-floor.jpg)'
    },
    "aria-hidden": true
  }), /*#__PURE__*/React.createElement("div", {
    className: "container mk-hero-photo-inner"
  }, /*#__PURE__*/React.createElement("span", {
    className: "marketing-eyebrow"
  }, "Built in Lagos \xB7 Made for Nigerian gyms"), /*#__PURE__*/React.createElement("h1", {
    className: "marketing-hero-title"
  }, "Run your gym the ", /*#__PURE__*/React.createElement("span", {
    className: "marketing-accent"
  }, "modern way")), /*#__PURE__*/React.createElement("p", {
    className: "marketing-hero-sub"
  }, "Check-ins, Paystack subscriptions, class booking and automated reminders \u2014 one mobile-first platform, light enough to fly on Nigerian networks."), /*#__PURE__*/React.createElement("div", {
    className: "marketing-hero-actions"
  }, /*#__PURE__*/React.createElement(Link, {
    href: "/signup",
    className: "gf-btn gf-btn-primary gf-btn-lg"
  }, "Launch your gym"), /*#__PURE__*/React.createElement(Link, {
    href: "/features",
    className: "gf-btn gf-btn-outline gf-btn-lg"
  }, "Explore features")), /*#__PURE__*/React.createElement("dl", {
    className: "marketing-stats"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("dt", null, "Members"), /*#__PURE__*/React.createElement("dd", null, "Unlimited")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("dt", null, "Locations"), /*#__PURE__*/React.createElement("dd", null, "Multi-gym")), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("dt", null, "Uptime"), /*#__PURE__*/React.createElement("dd", null, "99.9%"))))), /*#__PURE__*/React.createElement("section", {
    className: "marketing-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "marketing-section-title"
  }, "Everything your gym needs"), /*#__PURE__*/React.createElement("p", {
    className: "marketing-section-sub"
  }, "From the front desk to the back office, GymFlow covers the day-to-day."), /*#__PURE__*/React.createElement("div", {
    className: "marketing-grid"
  }, /*#__PURE__*/React.createElement(FeatureCard, {
    icon: ScanLine,
    title: "QR check-in",
    body: "Members scan a code; staff see attendance live. Works offline."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: CreditCard,
    title: "Paystack subscriptions",
    body: "Auto-renew, dunning, and saved cards \u2014 in Naira, no FX."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: CalendarDays,
    title: "Class scheduling",
    body: "Recurring classes, booking caps, waitlists and RSVP reminders."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: Users,
    title: "Staff & roles",
    body: "Owner, manager, front desk, accountant, instructor \u2014 each sees what they need."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: BarChart3,
    title: "Live analytics",
    body: "Revenue, churn, attendance \u2014 daily, monthly, exportable."
  }), /*#__PURE__*/React.createElement(FeatureCard, {
    icon: Smartphone,
    title: "Installs anywhere",
    body: "Add to home screen on Android & iOS. Push notifications optional."
  })))), /*#__PURE__*/React.createElement("section", {
    className: "marketing-section mk-gallery-strip"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "marketing-section-title"
  }, "Live in an afternoon"), /*#__PURE__*/React.createElement("p", {
    className: "marketing-section-sub"
  }, "No installs, no hardware. Three steps from signup to your first check-in."), /*#__PURE__*/React.createElement("div", {
    className: "mk-steps"
  }, /*#__PURE__*/React.createElement(Step, {
    n: 1,
    icon: Rocket,
    title: "Create your gym",
    body: "Sign up and get a branded subdomain, admin login, and default pricing plans provisioned instantly."
  }), /*#__PURE__*/React.createElement(Step, {
    n: 2,
    icon: QrCode,
    title: "Print your QR",
    body: "Download your static check-in QR from settings and post it at the entrance. Members scan to check in."
  }), /*#__PURE__*/React.createElement(Step, {
    n: 3,
    icon: TrendingUp,
    title: "Grow on autopilot",
    body: "Paystack auto-renews subscriptions, reminders go out on WhatsApp & email, and analytics update live."
  })))), /*#__PURE__*/React.createElement("section", {
    className: "marketing-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "marketing-section-title"
  }, "Made for real gyms"), /*#__PURE__*/React.createElement("p", {
    className: "marketing-section-sub"
  }, "From boutique studios to multi-floor facilities."), /*#__PURE__*/React.createElement("div", {
    className: "mk-gallery"
  }, GALLERY.map(g => /*#__PURE__*/React.createElement("div", {
    key: g.src,
    className: "mk-gallery-item"
  }, /*#__PURE__*/React.createElement(Image, {
    src: g.src,
    alt: g.alt,
    width: 600,
    height: 800,
    loading: "lazy",
    sizes: "(max-width: 760px) 50vw, 25vw"
  })))))), /*#__PURE__*/React.createElement("section", {
    className: "marketing-section mk-gallery-strip"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "marketing-section-title"
  }, "Loved by gym owners"), /*#__PURE__*/React.createElement("p", {
    className: "marketing-section-sub"
  }, "Built with feedback from independent gyms across Nigeria."), /*#__PURE__*/React.createElement("div", {
    className: "mk-testimonials"
  }, /*#__PURE__*/React.createElement(Testimonial, {
    quote: "Auto-debit alone paid for itself in the first week. Renewals just happen now \u2014 I stopped sending manual reminders.",
    name: "Tunde A.",
    gym: "Powerhouse Fitness, Lagos"
  }), /*#__PURE__*/React.createElement(Testimonial, {
    quote: "My front desk loves the QR check-in, and I finally see real numbers \u2014 who's active, who's lapsing, what we made.",
    name: "Ngozi E.",
    gym: "FlexZone, Abuja"
  }), /*#__PURE__*/React.createElement(Testimonial, {
    quote: "Setup took an afternoon. Members add it to their home screen and it feels like our own app. No hardware to buy.",
    name: "Kelechi O.",
    gym: "IronWorks Gym, PH"
  })))), /*#__PURE__*/React.createElement("section", {
    className: "marketing-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mk-cta"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "mk-cta-title"
  }, "Ready to run your gym the modern way?"), /*#__PURE__*/React.createElement("p", {
    className: "mk-cta-sub"
  }, "Launch your gym in an afternoon. From \u20A613,999/mo \xB7 cancel anytime \xB7 no setup fees."), /*#__PURE__*/React.createElement("div", {
    className: "marketing-hero-actions",
    style: {
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Link, {
    href: "/signup",
    className: "gf-btn gf-btn-primary gf-btn-lg"
  }, "Launch your gym"), /*#__PURE__*/React.createElement(Link, {
    href: "/pricing",
    className: "gf-btn gf-btn-outline gf-btn-lg"
  }, "See pricing")))))), /*#__PURE__*/React.createElement(MarketingFooter, null));
}
Object.assign(__ds_scope, { metadata, HomePage });
})(); } catch (e) { __ds_ns.__errors.push({ path: "app/(platform)/page.tsx", error: String((e && e.message) || e) }); }

// app/(platform)/pricing/metadata.ts
try { (() => {
const pricingMetadata = {
  title: 'Pricing',
  description: 'One flat plan, no per-member fees. From ₦13,999/month — pay monthly, quarterly, or annually.'
};
Object.assign(__ds_scope, { pricingMetadata });
})(); } catch (e) { __ds_ns.__errors.push({ path: "app/(platform)/pricing/metadata.ts", error: String((e && e.message) || e) }); }

// app/(platform)/pricing/page.tsx
try { (() => {
const SITE = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://gymflow.ng';
const PRICING_LD = {
  '@context': 'https://schema.org',
  '@type': 'Product',
  name: 'GymFlow',
  description: 'Multi-tenant gym management SaaS for Nigerian fitness businesses.',
  brand: {
    '@type': 'Brand',
    name: 'GymFlow'
  },
  offers: BILLING_PERIODS.map(p => ({
    '@type': 'Offer',
    name: PLATFORM_PRICING[p].label,
    price: String(PLATFORM_PRICING[p].amount),
    priceCurrency: 'NGN',
    url: `${SITE}/pricing`,
    availability: 'https://schema.org/InStock',
    priceSpecification: {
      '@type': 'UnitPriceSpecification',
      price: String(PLATFORM_PRICING[p].amount),
      priceCurrency: 'NGN',
      unitText: PLATFORM_PRICING[p].per
    }
  }))
};
const INCLUDED = ['Unlimited members & staff', 'Paystack payments & auto-debit', 'QR check-in & attendance', 'Classes, booking & waitlists', 'Instructor portal & payouts', 'Analytics, P&L & exports', 'WhatsApp & email reminders', 'Multi-location ready', 'Daily backups'];
function PricingPage() {
  return /*#__PURE__*/React.createElement("div", {
    className: "marketing"
  }, /*#__PURE__*/React.createElement("script", {
    type: "application/ld+json",
    dangerouslySetInnerHTML: {
      __html: JSON.stringify(PRICING_LD)
    }
  }), /*#__PURE__*/React.createElement(MarketingNav, null), /*#__PURE__*/React.createElement("main", {
    id: "main-content",
    tabIndex: -1
  }, /*#__PURE__*/React.createElement("header", {
    className: "marketing-hero mk-subhero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("span", {
    className: "marketing-eyebrow"
  }, "Pricing"), /*#__PURE__*/React.createElement("h1", {
    className: "marketing-hero-title"
  }, "Simple Naira pricing"), /*#__PURE__*/React.createElement("p", {
    className: "marketing-hero-sub"
  }, "No per-member fees. Every plan includes everything \u2014 pick the billing cycle that suits you."))), /*#__PURE__*/React.createElement("section", {
    className: "marketing-section",
    style: {
      paddingTop: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mk-price-grid"
  }, BILLING_PERIODS.map(b => {
    const p = PLATFORM_PRICING[b];
    const savings = periodSavings(b);
    const monthly = p.months > 1 ? Math.round(p.amount / p.months) : null;
    const best = b === 'annual';
    return /*#__PURE__*/React.createElement("article", {
      key: b,
      className: `mk-price-card${best ? ' best' : ''}`
    }, best && /*#__PURE__*/React.createElement("span", {
      className: "mk-price-badge"
    }, "Best value"), /*#__PURE__*/React.createElement("h3", {
      className: "mk-price-name"
    }, p.label), /*#__PURE__*/React.createElement("div", {
      className: "mk-price-amount"
    }, formatNaira(p.amount), /*#__PURE__*/React.createElement("span", null, "/", p.per)), /*#__PURE__*/React.createElement("p", {
      className: "mk-price-note"
    }, monthly ? `≈ ${formatNaira(monthly)}/mo` : 'Billed monthly', savings > 0 ? ` · save ${formatNaira(savings)}` : ''), /*#__PURE__*/React.createElement(Link, {
      href: "/signup",
      className: `gf-btn gf-btn-full ${best ? 'gf-btn-primary' : 'gf-btn-secondary'}`
    }, "Launch your gym"), /*#__PURE__*/React.createElement("ul", {
      className: "mk-price-list"
    }, INCLUDED.map(i => /*#__PURE__*/React.createElement("li", {
      key: i
    }, /*#__PURE__*/React.createElement(Check, {
      size: 15,
      strokeWidth: 2.5
    }), " ", i))));
  })), /*#__PURE__*/React.createElement("p", {
    className: "mk-price-foot"
  }, "Cancel anytime \xB7 no setup fees \xB7 no per-member fees. Paystack transaction fees apply per payment."))), /*#__PURE__*/React.createElement("section", {
    id: "faq",
    className: "marketing-section mk-faq-section"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "marketing-section-title"
  }, "Questions, answered"), /*#__PURE__*/React.createElement("p", {
    className: "marketing-section-sub"
  }, "Everything you need to know before you start."), /*#__PURE__*/React.createElement("div", {
    className: "mk-faq"
  }, /*#__PURE__*/React.createElement(Faq, {
    q: "Do my members need to download an app?",
    a: "No. GymFlow is a PWA \u2014 members open your gym's link in any browser and can optionally add it to their home screen. It works on Android and iOS, even on slow connections."
  }), /*#__PURE__*/React.createElement(Faq, {
    q: "How do payments work?",
    a: "Members pay in Naira via Paystack (card or bank transfer). Cards are tokenised so renewals happen automatically. Funds settle into your gym's own Paystack subaccount \u2014 we never hold your money."
  }), /*#__PURE__*/React.createElement(Faq, {
    q: "Is there a per-member fee?",
    a: "No. Your GymFlow plan covers unlimited members and staff. The only other cost is Paystack's standard transaction fee, paid by you or passed to members."
  }), /*#__PURE__*/React.createElement(Faq, {
    q: "Can I run more than one location?",
    a: "Yes. Owners and managers can belong to multiple gyms with a single login, and each location gets its own branded subdomain and isolated data."
  }), /*#__PURE__*/React.createElement(Faq, {
    q: "Can I change or cancel my plan?",
    a: "Anytime. Switch between monthly, quarterly and annual, or cancel \u2014 there are no setup fees or lock-in contracts."
  }), /*#__PURE__*/React.createElement(Faq, {
    q: "What about my members' data?",
    a: "Every gym's data is isolated at the database level with row-level security. No gym can ever see another gym's members, payments, or check-ins."
  }))))), /*#__PURE__*/React.createElement(MarketingFooter, null));
}
Object.assign(__ds_scope, { metadata: __ds_scope.pricingMetadata, PricingPage });
})(); } catch (e) { __ds_ns.__errors.push({ path: "app/(platform)/pricing/page.tsx", error: String((e && e.message) || e) }); }

// app/gym/[slug]/admin/admin-shell.tsx
try { (() => {
'use client';

const {
  useState
} = React;
const NAV = [{
  href: '/admin/dashboard',
  label: 'Members',
  section: 'main',
  icon: Users
}, {
  href: '/admin/staff-checkin',
  label: 'Check-In',
  section: 'main',
  icon: ScanLine
}, {
  href: '/admin/analytics',
  label: 'Analytics',
  section: 'main',
  icon: BarChart3
}, {
  href: '/admin/classes',
  label: 'Classes',
  section: 'main',
  icon: CalendarDays
}, {
  href: '/admin/instructors',
  label: 'Instructors',
  section: 'main',
  icon: GraduationCap
}, {
  href: '/admin/pt-packs',
  label: 'PT Packs',
  section: 'main',
  icon: Dumbbell
}, {
  href: '/admin/pricing',
  label: 'Pricing',
  section: 'admin',
  icon: Tag
}, {
  href: '/admin/reminders',
  label: 'Reminders',
  section: 'admin',
  icon: Bell
}, {
  href: '/admin/announcements',
  label: 'Announcements',
  section: 'admin',
  icon: Megaphone
}, {
  href: '/admin/operations',
  label: 'Operations',
  section: 'admin',
  icon: Wrench
}, {
  href: '/admin/business-hours',
  label: 'Hours',
  section: 'admin',
  icon: Clock
}, {
  href: '/admin/waiver',
  label: 'Waiver',
  section: 'admin',
  icon: FileText
}, {
  href: '/admin/audit',
  label: 'Audit',
  section: 'admin',
  icon: ShieldCheck
}, {
  href: '/admin/wallet',
  label: 'Wallet',
  section: 'admin',
  icon: Wallet
}, {
  href: '/admin/payouts',
  label: 'Payouts',
  section: 'admin',
  icon: BanknoteArrowUp
}, {
  href: '/admin/billing',
  label: 'Billing',
  section: 'admin',
  icon: CreditCard
}, {
  href: '/admin/settings',
  label: 'Settings',
  section: 'admin',
  icon: Settings
}];
function AdminShell({
  children,
  slug,
  gymName,
  role,
  userName,
  userInitial
}) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const isActive = href => pathname?.endsWith(href);
  const mainItems = NAV.filter(i => i.section === 'main');
  const adminItems = NAV.filter(i => i.section === 'admin');

  // Reuse the nav array as the command-palette dataset — every page is
  // already in NAV, so ⌘K and the sidebar can't drift out of sync.
  const cmdItems = NAV.map(i => ({
    href: i.href,
    label: i.label,
    icon: i.icon,
    hint: i.section === 'main' ? 'Main' : 'Admin'
  }));

  // Live member search — fires on every keystroke (debounced inside the
  // palette) so typing "tunde" surfaces members alongside the static pages.
  // Server action does its own requireStaff(slug) gate, so even a malicious
  // client crafting the call directly would be rejected.
  const fetchExtra = async query => {
    const hits = await searchMembers(slug, query);
    return hits.map(m => ({
      id: m.id,
      label: m.label,
      href: m.href,
      hint: m.email ?? undefined
    }));
  };
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(CommandPalette, {
    items: cmdItems,
    placeholder: "Jump to a page or search a member\u2026",
    listLabel: "Admin pages and members",
    fetchExtra: fetchExtra,
    extraSectionLabel: "Members"
  }), /*#__PURE__*/React.createElement("div", {
    className: `gf-sidebar-overlay${open ? ' open' : ''}`,
    onClick: () => setOpen(false)
  }), /*#__PURE__*/React.createElement("aside", {
    className: `gf-sidebar${open ? ' open' : ''}`
  }, /*#__PURE__*/React.createElement("div", {
    className: "gf-sidebar-header"
  }, /*#__PURE__*/React.createElement(Link, {
    href: "/admin/dashboard",
    className: "gf-logo gf-logo-sm"
  }, /*#__PURE__*/React.createElement(LogoMark, null), /*#__PURE__*/React.createElement("span", {
    className: "gf-logo-text"
  }, "Gym", /*#__PURE__*/React.createElement("em", null, "Flow"))), /*#__PURE__*/React.createElement("div", {
    className: "gf-sidebar-gym-name"
  }, gymName)), /*#__PURE__*/React.createElement("nav", {
    className: "gf-sidebar-nav"
  }, /*#__PURE__*/React.createElement("span", {
    className: "gf-sidebar-section"
  }, "Main"), mainItems.map(item => {
    const Icon = item.icon;
    return /*#__PURE__*/React.createElement(Link, {
      key: item.href,
      href: item.href,
      className: `gf-nav-item${isActive(item.href) ? ' active' : ''}`,
      onClick: () => setOpen(false)
    }, /*#__PURE__*/React.createElement(Icon, {
      size: 17,
      strokeWidth: 1.75
    }), /*#__PURE__*/React.createElement("span", null, item.label));
  }), /*#__PURE__*/React.createElement("span", {
    className: "gf-sidebar-section"
  }, "Admin"), adminItems.map(item => {
    const Icon = item.icon;
    return /*#__PURE__*/React.createElement(Link, {
      key: item.href,
      href: item.href,
      className: `gf-nav-item${isActive(item.href) ? ' active' : ''}`,
      onClick: () => setOpen(false)
    }, /*#__PURE__*/React.createElement(Icon, {
      size: 17,
      strokeWidth: 1.75
    }), /*#__PURE__*/React.createElement("span", null, item.label));
  })), /*#__PURE__*/React.createElement("div", {
    className: "gf-sidebar-footer"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "gf-avatar gf-avatar-sm",
    style: {
      background: 'var(--gf-brand-soft)',
      color: 'var(--gf-brand)'
    }
  }, userInitial), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.8125rem',
      fontWeight: 600,
      color: 'var(--gf-text)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, userName), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '0.6875rem',
      color: 'var(--gf-text-muted)',
      fontWeight: 500
    }
  }, role))), /*#__PURE__*/React.createElement("form", {
    action: signOut
  }, /*#__PURE__*/React.createElement("button", {
    type: "submit",
    className: "gf-btn-icon gf-btn-ghost",
    title: "Sign out",
    "aria-label": "Sign out"
  }, /*#__PURE__*/React.createElement(LogOut, {
    size: 16,
    strokeWidth: 1.75
  })))))), /*#__PURE__*/React.createElement("div", {
    className: "gf-main"
  }, /*#__PURE__*/React.createElement("header", {
    className: "gf-topbar"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    id: "hamburger",
    className: "gf-btn-icon gf-btn-ghost",
    onClick: () => setOpen(v => !v),
    "aria-label": "Toggle menu"
  }, /*#__PURE__*/React.createElement(Menu, {
    size: 20,
    strokeWidth: 1.75
  })), /*#__PURE__*/React.createElement("span", {
    className: "gf-topbar-title"
  }, gymName), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "gf-topbar-cmdk",
    onClick: () => window.dispatchEvent(new KeyboardEvent('keydown', {
      key: 'k',
      metaKey: true
    })),
    "aria-label": "Open command palette",
    title: "Jump to any page (\u2318K)"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", null, "Jump to\u2026"), /*#__PURE__*/React.createElement("kbd", null, "\u2318K")))), children));
}
Object.assign(__ds_scope, { AdminShell });
})(); } catch (e) { __ds_ns.__errors.push({ path: "app/gym/[slug]/admin/admin-shell.tsx", error: String((e && e.message) || e) }); }

// components/marketing/footer.tsx
try { (() => {
function MarketingFooter() {
  return /*#__PURE__*/React.createElement("footer", {
    id: "contact",
    className: "marketing-footer"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container mk-footer-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mk-footer-brand"
  }, /*#__PURE__*/React.createElement(Link, {
    href: "/",
    className: "marketing-logo"
  }, /*#__PURE__*/React.createElement("span", {
    className: "marketing-logo-icon",
    "aria-hidden": true
  }, /*#__PURE__*/React.createElement("svg", {
    width: "20",
    height: "20",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "#fff",
    strokeWidth: 2.6,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M19.5 7.2A8 8 0 1 0 20 12h-6"
  }))), /*#__PURE__*/React.createElement("span", null, "Gym", /*#__PURE__*/React.createElement("span", {
    className: "marketing-logo-em"
  }, "Flow"))), /*#__PURE__*/React.createElement("p", {
    className: "mk-footer-tag"
  }, "Modern gym management for Nigerian fitness businesses.")), /*#__PURE__*/React.createElement("div", {
    className: "mk-footer-col"
  }, /*#__PURE__*/React.createElement("h4", null, "Product"), /*#__PURE__*/React.createElement(Link, {
    href: "/features"
  }, "Features"), /*#__PURE__*/React.createElement(Link, {
    href: "/pricing"
  }, "Pricing"), /*#__PURE__*/React.createElement(Link, {
    href: "/about"
  }, "Gallery")), /*#__PURE__*/React.createElement("div", {
    className: "mk-footer-col"
  }, /*#__PURE__*/React.createElement("h4", null, "Account"), /*#__PURE__*/React.createElement(Link, {
    href: "/signup"
  }, "Launch your gym"), /*#__PURE__*/React.createElement(Link, {
    href: "/login"
  }, "Sign in")), /*#__PURE__*/React.createElement("div", {
    className: "mk-footer-col"
  }, /*#__PURE__*/React.createElement("h4", null, "Get in touch"), /*#__PURE__*/React.createElement("a", {
    href: "mailto:hello@gymflow.ng"
  }, "hello@gymflow.ng"), /*#__PURE__*/React.createElement("a", {
    href: "tel:+2348166938327"
  }, "0816 693 8327"), /*#__PURE__*/React.createElement("span", {
    className: "mk-footer-muted"
  }, "41 Ogudu Road, Lagos"))), /*#__PURE__*/React.createElement("div", {
    className: "container mk-footer-bottom"
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 ", new Date().getFullYear(), " GymFlow \xB7 Made in Lagos"), /*#__PURE__*/React.createElement("span", null, "Powered by Paystack \xB7 Supabase \xB7 Vercel")));
}
Object.assign(__ds_scope, { MarketingFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/footer.tsx", error: String((e && e.message) || e) }); }

// components/marketing/nav.tsx
try { (() => {
function MarketingNav() {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("a", {
    href: "#main-content",
    className: "skip-link"
  }, "Skip to main content"), /*#__PURE__*/React.createElement("nav", {
    className: "marketing-nav",
    "aria-label": "Primary"
  }, /*#__PURE__*/React.createElement("div", {
    className: "container marketing-nav-inner"
  }, /*#__PURE__*/React.createElement(Link, {
    href: "/",
    className: "marketing-logo"
  }, /*#__PURE__*/React.createElement("span", {
    className: "marketing-logo-icon",
    "aria-hidden": true
  }, /*#__PURE__*/React.createElement("svg", {
    width: "20",
    height: "20",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "#fff",
    strokeWidth: 2.6,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M19.5 7.2A8 8 0 1 0 20 12h-6"
  }))), /*#__PURE__*/React.createElement("span", null, "Gym", /*#__PURE__*/React.createElement("span", {
    className: "marketing-logo-em"
  }, "Flow"))), /*#__PURE__*/React.createElement("div", {
    className: "marketing-nav-links"
  }, /*#__PURE__*/React.createElement(Link, {
    href: "/features",
    className: "marketing-nav-link"
  }, "Features"), /*#__PURE__*/React.createElement(Link, {
    href: "/pricing",
    className: "marketing-nav-link"
  }, "Pricing"), /*#__PURE__*/React.createElement(Link, {
    href: "/about",
    className: "marketing-nav-link"
  }, "Gallery"), /*#__PURE__*/React.createElement(Link, {
    href: "/login",
    className: "marketing-nav-link"
  }, "Sign in"), /*#__PURE__*/React.createElement(Link, {
    href: "/signup",
    className: "gf-btn gf-btn-primary"
  }, "Get started"), /*#__PURE__*/React.createElement(ThemeToggleButton, null)))));
}
Object.assign(__ds_scope, { MarketingNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/nav.tsx", error: String((e && e.message) || e) }); }

// components/marketing/sections.tsx
try { (() => {
function FeatureCard({
  icon: Icon,
  title,
  body
}) {
  return /*#__PURE__*/React.createElement("article", {
    className: "marketing-feature"
  }, /*#__PURE__*/React.createElement("div", {
    className: "marketing-feature-icon",
    "aria-hidden": true
  }, /*#__PURE__*/React.createElement(Icon, {
    size: 22,
    strokeWidth: 1.75
  })), /*#__PURE__*/React.createElement("h3", {
    className: "marketing-feature-title"
  }, title), /*#__PURE__*/React.createElement("p", {
    className: "marketing-feature-body"
  }, body));
}
function Step({
  n,
  icon: Icon,
  title,
  body
}) {
  return /*#__PURE__*/React.createElement("article", {
    className: "mk-step"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mk-step-top"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mk-step-num"
  }, n), /*#__PURE__*/React.createElement("span", {
    className: "mk-step-icon",
    "aria-hidden": true
  }, /*#__PURE__*/React.createElement(Icon, {
    size: 20,
    strokeWidth: 1.75
  }))), /*#__PURE__*/React.createElement("h3", {
    className: "mk-step-title"
  }, title), /*#__PURE__*/React.createElement("p", {
    className: "mk-step-body"
  }, body));
}
function Testimonial({
  quote,
  name,
  gym
}) {
  return /*#__PURE__*/React.createElement("article", {
    className: "mk-testimonial"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mk-stars",
    "aria-hidden": true
  }, [0, 1, 2, 3, 4].map(i => /*#__PURE__*/React.createElement(Star, {
    key: i,
    size: 15,
    strokeWidth: 0,
    fill: "var(--gf-accent)"
  }))), /*#__PURE__*/React.createElement("p", {
    className: "mk-testimonial-quote"
  }, "\u201C", quote, "\u201D"), /*#__PURE__*/React.createElement("div", {
    className: "mk-testimonial-by"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mk-testimonial-avatar",
    "aria-hidden": true
  }, name.charAt(0)), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    className: "mk-testimonial-name"
  }, name), /*#__PURE__*/React.createElement("span", {
    className: "mk-testimonial-gym"
  }, gym))));
}
function Faq({
  q,
  a
}) {
  return /*#__PURE__*/React.createElement("details", {
    className: "mk-faq-item"
  }, /*#__PURE__*/React.createElement("summary", {
    className: "mk-faq-q"
  }, /*#__PURE__*/React.createElement("span", null, q), /*#__PURE__*/React.createElement("span", {
    className: "mk-faq-plus",
    "aria-hidden": true
  }, /*#__PURE__*/React.createElement(Check, {
    size: 16,
    strokeWidth: 2.5
  }))), /*#__PURE__*/React.createElement("p", {
    className: "mk-faq-a"
  }, a));
}
Object.assign(__ds_scope, { FeatureCard, Step, Testimonial, Faq });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/marketing/sections.tsx", error: String((e && e.message) || e) }); }

// revamp/admin-shell.js
try { (() => {
// ── GymFlow admin shell: renders sidebar + topbar across all admin pages ──
// Usage: <aside id="admSidebar"></aside> ... <header id="admTop"></header>
//   adminShell('members', { search:'Search…', action:{label,icon,href} });

(function () {
  // persisted theme (shared key with theme.js)
  try {
    const t = localStorage.getItem('gf-theme');
    if (t) document.documentElement.setAttribute('data-theme', t);
  } catch (e) {}
  const NAV = [{
    s: 'Main',
    items: [{
      k: 'overview',
      label: 'Overview',
      icon: 'layout-dashboard',
      href: 'admin.html'
    }, {
      k: 'members',
      label: 'Members',
      icon: 'users',
      href: 'admin-members.html'
    }, {
      k: 'checkin',
      label: 'Check-In',
      icon: 'scan-line',
      href: 'admin-checkin.html'
    }, {
      k: 'analytics',
      label: 'Analytics',
      icon: 'bar-chart-3',
      href: 'admin-analytics.html'
    }]
  }, {
    s: 'Operations',
    items: [{
      k: 'staff',
      label: 'Staff',
      icon: 'user-cog',
      href: 'admin-staff.html'
    }, {
      k: 'facility',
      label: 'Facility',
      icon: 'dumbbell',
      href: 'admin-facility.html'
    }, {
      k: 'classes',
      label: 'Classes',
      icon: 'calendar-days',
      href: 'admin-classes.html'
    }]
  }, {
    s: 'Admin',
    items: [{
      k: 'pricing',
      label: 'Pricing',
      icon: 'tag',
      href: 'admin-pricing.html'
    }, {
      k: 'reminders',
      label: 'Reminders',
      icon: 'bell',
      href: 'admin-reminders.html'
    }, {
      k: 'wallet',
      label: 'Wallet',
      icon: 'wallet',
      href: 'admin-wallet.html'
    }, {
      k: 'settings',
      label: 'Settings',
      icon: 'settings',
      href: 'admin-settings.html'
    }]
  }];

  // self-contained shell styles
  if (!document.getElementById('admShellCss')) {
    const css = document.createElement('style');
    css.id = 'admShellCss';
    css.textContent = `
      .sb-gym { display:flex; align-items:center; gap:10px; margin-top:14px; padding:8px; border-radius:var(--gf-radius-sm); background:var(--gf-elevated); border:1px solid var(--gf-border); }
      .sb-gym .gf-avatar { background:var(--gf-brand-soft); color:var(--gf-brand); border-color:var(--gf-brand-glow); }
      .sb-gym small { color:var(--gf-text-muted); font-size:0.66rem; display:block; }
      .sb-gym strong { font-family:var(--gf-font-display); font-size:0.85rem; }
      .bell { position:relative; }
      .bell::after { content:''; position:absolute; top:9px; right:10px; width:7px; height:7px; border-radius:50%; background:var(--gf-danger); border:2px solid var(--gf-elevated); }
      .sb-foot-user { display:flex; align-items:center; gap:10px; }
      .sb-foot-user .gf-avatar { background:var(--gf-brand-soft); color:var(--gf-brand); }
    `;
    document.head.appendChild(css);
  }

  // global toast + dead-link / unwired-button feedback (attached once)
  function gfToast(msg) {
    let t = document.getElementById('gfToast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'gfToast';
      t.className = 'toast';
      t.innerHTML = '<i data-lucide="check-circle-2"></i><span></span>';
      document.body.appendChild(t);
    }
    t.querySelector('span').textContent = msg;
    if (window.lucide) lucide.createIcons();
    t.classList.add('show');
    clearTimeout(t._tm);
    t._tm = setTimeout(() => t.classList.remove('show'), 2000);
  }
  window.gfToast = gfToast;

  // Inject a "Mobile view" toggle when the page declares a counterpart.
  function injectViewToggle() {
    if (!document.body || document.querySelector('.viewtoggle')) return;
    const mobile = document.body.getAttribute('data-gf-mobile');
    const desktop = document.body.getAttribute('data-gf-desktop');
    const target = mobile || desktop;
    if (!target) return;
    const a = document.createElement('a');
    a.href = target;
    a.className = 'viewtoggle';
    a.innerHTML = '<i data-lucide="' + (mobile ? 'smartphone' : 'monitor') + '"></i><span>' + (mobile ? 'Mobile view' : 'Desktop view') + '</span>';
    document.body.appendChild(a);
    if (window.lucide) lucide.createIcons();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', injectViewToggle);else injectViewToggle();
  function gfLabel(el) {
    const s = (el.getAttribute('aria-label') || el.title || el.textContent || '').trim().replace(/\s+/g, ' ');
    return s ? s.slice(0, 40) + ' — prototype' : 'Prototype action';
  }
  document.addEventListener('click', function (e) {
    const a = e.target.closest('a[href="#"]');
    if (a) {
      e.preventDefault();
      gfToast(gfLabel(a));
      return;
    }
    const b = e.target.closest('.gf-btn, .icon-btn');
    if (b && !b.onclick) {
      if (b.tagName === 'A') {
        const h = b.getAttribute('href');
        if (h && h !== '#') return;
      }
      if (b.type === 'submit') return;
      gfToast(gfLabel(b));
    }
  });
  window.adminShell = function (active, topOpts) {
    topOpts = topOpts || {};
    const sb = document.getElementById('admSidebar');
    const top = document.getElementById('admTop');
    if (sb) {
      sb.innerHTML = `
        <div class="gf-sidebar-header">
          <a class="brand" href="marketing.html" style="text-decoration:none">
            <img class="mark-sm" src="../assets/logomark-v2.svg" alt="" />
            <span class="brand-tx">Gym<em>Flow</em></span>
          </a>
          <div class="sb-gym">
            <span class="gf-avatar gf-avatar-sm">P</span>
            <div style="min-width:0"><strong>Powerhouse Fitness</strong><small>Lekki · powerhouse.gymflow.ng</small></div>
          </div>
        </div>
        <nav class="gf-sidebar-nav">
          ${NAV.map(group => `
            <span class="gf-sidebar-section">${group.s}</span>
            ${group.items.map(i => `
              <a class="gf-nav-item${i.k === active ? ' active' : ''}" href="${i.href}">
                <i data-lucide="${i.icon}"></i><span>${i.label}</span>
              </a>`).join('')}
          `).join('')}
        </nav>
        <div class="gf-sidebar-footer">
          <div class="sb-foot-user">
            <span class="gf-avatar gf-avatar-sm">A</span>
            <div style="min-width:0;flex:1">
              <div style="font-family:var(--gf-font-display);font-size:0.8125rem;font-weight:600">Adunni O.</div>
              <div style="font-size:0.68rem;color:var(--gf-text-muted)">Owner</div>
            </div>
            <a class="icon-btn" href="login.html" style="width:32px;height:32px" title="Sign out"><i data-lucide="log-out"></i></a>
          </div>
        </div>`;
    }
    if (top) {
      const act = topOpts.action;
      top.innerHTML = `
        <div class="search" style="flex:1;max-width:460px">
          <i data-lucide="search"></i>
          <input placeholder="${topOpts.search || 'Search…'}" />
        </div>
        <div style="flex:1"></div>
        <button class="icon-btn" id="admTheme" title="Toggle theme"><i data-lucide="moon"></i></button>
        <button class="icon-btn bell" title="Notifications"><i data-lucide="bell"></i></button>
        ${act ? `<a class="gf-btn gf-btn-primary" href="${act.href || '#'}"><i data-lucide="${act.icon}" style="width:16px;height:16px"></i> ${act.label}</a>` : ''}`;
    }
    if (window.lucide) lucide.createIcons();
    if (!document.getElementById('gfNotifJs')) {
      const ns = document.createElement('script');
      ns.id = 'gfNotifJs';
      ns.src = 'notifications-panel.js';
      document.body.appendChild(ns);
    }
    if (!document.getElementById('gfUiJs')) {
      const us = document.createElement('script');
      us.id = 'gfUiJs';
      us.src = 'ui.js';
      document.body.appendChild(us);
    }
    const tbtn = document.getElementById('admTheme');
    if (tbtn) {
      const ico = () => {
        const d = document.documentElement.getAttribute('data-theme') === 'dark';
        tbtn.innerHTML = `<i data-lucide="${d ? 'sun' : 'moon'}"></i>`;
        if (window.lucide) lucide.createIcons();
      };
      ico();
      tbtn.onclick = () => {
        const dark = document.documentElement.getAttribute('data-theme') === 'dark';
        const next = dark ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        try {
          localStorage.setItem('gf-theme', next);
        } catch (e) {}
        ico();
      };
    }
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "revamp/admin-shell.js", error: String((e && e.message) || e) }); }

// revamp/instructor-shell.js
try { (() => {
// ── GymFlow instructor shell: sidebar + topbar for coach pages ──
// Usage: <aside id="coachSidebar"></aside> ... <header id="coachTop"></header>
//   coachShell('classes', { search:'Search…', action:{label,icon,href} });
(function () {
  try {
    const t = localStorage.getItem('gf-theme');
    if (t) document.documentElement.setAttribute('data-theme', t);
  } catch (e) {}
  const NAV = [{
    s: 'Coaching',
    items: [{
      k: 'schedule',
      label: 'My schedule',
      icon: 'calendar-clock',
      href: 'instructor.html'
    }, {
      k: 'classes',
      label: 'Classes',
      icon: 'calendar-days',
      href: 'instructor-classes.html'
    }, {
      k: 'clients',
      label: 'PT clients',
      icon: 'dumbbell',
      href: 'instructor-clients.html'
    }, {
      k: 'attendance',
      label: 'Attendance',
      icon: 'clipboard-check',
      href: 'instructor-attendance.html'
    }]
  }, {
    s: 'Money',
    items: [{
      k: 'earnings',
      label: 'Earnings',
      icon: 'wallet',
      href: 'instructor-earnings.html'
    }, {
      k: 'payouts',
      label: 'Payouts',
      icon: 'banknote',
      href: 'instructor-payouts.html'
    }, {
      k: 'settings',
      label: 'Settings',
      icon: 'settings',
      href: 'instructor-settings.html'
    }]
  }];
  if (!document.getElementById('coachShellCss')) {
    const css = document.createElement('style');
    css.id = 'coachShellCss';
    css.textContent = `
      .sb-role { display:flex; align-items:center; gap:10px; margin-top:14px; padding:8px; border-radius:var(--gf-radius-sm); background:var(--gf-elevated); border:1px solid var(--gf-border); }
      .sb-role .gf-avatar { background:var(--gf-brand-soft); color:var(--gf-brand); border-color:var(--gf-brand-glow); }
      .sb-role small { color:var(--gf-text-muted); font-size:0.66rem; display:block; }
      .sb-role strong { font-family:var(--gf-font-display); font-size:0.85rem; }
      .bell { position:relative; }
      .bell::after { content:''; position:absolute; top:9px; right:10px; width:7px; height:7px; border-radius:50%; background:var(--gf-danger); border:2px solid var(--gf-elevated); }
    `;
    document.head.appendChild(css);
  }
  window.coachShell = function (active, topOpts) {
    topOpts = topOpts || {};
    const sb = document.getElementById('coachSidebar');
    const top = document.getElementById('coachTop');
    if (sb) {
      sb.innerHTML = `
        <div class="gf-sidebar-header">
          <a class="brand" href="marketing.html" style="text-decoration:none"><img class="mark-sm" src="../assets/logomark-v2.svg" alt="" /><span class="brand-tx">Gym<em>Flow</em></span></a>
          <div class="sb-role"><span class="gf-avatar gf-avatar-sm">F</span><div><strong>Coach Femi</strong><small>Instructor · Powerhouse</small></div></div>
        </div>
        <nav class="gf-sidebar-nav">
          ${NAV.map(g => `<span class="gf-sidebar-section">${g.s}</span>${g.items.map(i => `<a class="gf-nav-item${i.k === active ? ' active' : ''}" href="${i.href}"><i data-lucide="${i.icon}"></i><span>${i.label}</span></a>`).join('')}`).join('')}
        </nav>
        <div class="gf-sidebar-footer"><a class="gf-nav-item" href="login.html"><i data-lucide="log-out"></i><span>Sign out</span></a></div>`;
    }
    if (top) {
      const act = topOpts.action;
      top.innerHTML = `
        <div class="search" style="flex:1;max-width:420px"><i data-lucide="search"></i><input placeholder="${topOpts.search || 'Search…'}" /></div>
        <div style="flex:1"></div>
        <button class="icon-btn" data-theme-toggle data-theme-icon title="Toggle theme"><i data-lucide="moon"></i></button>
        <button class="icon-btn bell"><i data-lucide="bell"></i></button>
        ${act ? `<a class="gf-btn gf-btn-primary" href="${act.href || '#'}"><i data-lucide="${act.icon}" style="width:16px;height:16px"></i> ${act.label}</a>` : ''}`;
    }
    if (window.lucide) lucide.createIcons();
    if (window.gfSyncThemeIcons) window.gfSyncThemeIcons();
    if (!document.getElementById('gfNotifJs')) {
      const ns = document.createElement('script');
      ns.id = 'gfNotifJs';
      ns.src = 'notifications-panel.js';
      document.body.appendChild(ns);
    }
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "revamp/instructor-shell.js", error: String((e && e.message) || e) }); }

// revamp/member.js
try { (() => {
/* ============================================================
   GymFlow Member app — logic
   Views: home · schedule · classdetail · checkin · wallet ·
          receipt · renew · notifications · profile
   ============================================================ */
const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];

/* ───────────────────────── data ───────────────────────── */

// week calendar strip — today is Wed 11
const WEEK = [{
  dow: 'Mon',
  date: 9,
  key: 'mon'
}, {
  dow: 'Tue',
  date: 10,
  key: 'tue'
}, {
  dow: 'Wed',
  date: 11,
  key: 'wed',
  today: true
}, {
  dow: 'Thu',
  date: 12,
  key: 'thu'
}, {
  dow: 'Fri',
  date: 13,
  key: 'fri'
}, {
  dow: 'Sat',
  date: 14,
  key: 'sat'
}, {
  dow: 'Sun',
  date: 15,
  key: 'sun'
}];

// classes by day — full detail consumed by openClass()
const SCHEDULE = {
  mon: [{
    n: 'Power Lifting',
    time: '09:00',
    ap: 'AM',
    coach: 'Coach Femi',
    cap: '12/15 booked',
    state: 'book',
    img: 'gym-barbell.jpg',
    dur: '60 min',
    when: 'Mon 9 · 09:00 · 60 min',
    desc: 'Strength-focused barbell session covering squat, bench and deadlift technique with coached progressions.'
  }, {
    n: 'Yoga Flow',
    time: '19:00',
    ap: 'PM',
    coach: 'Coach Ada',
    cap: '9/16 booked',
    state: 'book',
    img: 'gym-kettlebells.jpg',
    dur: '60 min',
    when: 'Mon 9 · 19:00 · 60 min',
    desc: 'A calming vinyasa flow to stretch, breathe and unwind. Mats provided — just bring yourself.'
  }],
  tue: [{
    n: 'Sunrise HIIT',
    time: '06:30',
    ap: 'AM',
    coach: 'Coach Bisi',
    cap: '16/20 booked',
    state: 'book',
    img: 'gym-studio.jpg',
    dur: '45 min',
    when: 'Tue 10 · 06:30 · 45 min',
    desc: 'A fast, full-body HIIT circuit to start your day. Short bursts of high-intensity work with active recovery — scalable for every level.'
  }, {
    n: 'Strength 101',
    time: '17:00',
    ap: 'PM',
    coach: 'Coach Femi',
    cap: '8/14 booked',
    state: 'book',
    img: 'gym-machines.jpg',
    dur: '50 min',
    when: 'Tue 10 · 17:00 · 50 min',
    desc: 'A coached intro to the big lifts and machines — perfect if you are building a base.'
  }],
  wed: [{
    n: 'Sunrise HIIT',
    time: '06:30',
    ap: 'AM',
    coach: 'Coach Bisi',
    cap: '18/20 booked',
    state: 'book',
    img: 'gym-studio.jpg',
    dur: '45 min',
    when: 'Today · 06:30 · 45 min',
    desc: 'A fast, full-body HIIT circuit to start your day. Short bursts of high-intensity work with active recovery — scalable for every level.',
    few: true
  }, {
    n: 'Power Lifting',
    time: '09:00',
    ap: 'AM',
    coach: 'Coach Femi',
    cap: '12/15 booked',
    state: 'book',
    img: 'gym-barbell.jpg',
    dur: '60 min',
    when: 'Today · 09:00 · 60 min',
    desc: 'Strength-focused barbell session covering squat, bench and deadlift technique with coached progressions.'
  }, {
    n: 'Spin Class',
    time: '17:30',
    ap: 'PM',
    coach: 'Coach Tobi',
    cap: '22/24 booked',
    state: 'booked',
    img: 'gym-bikes.jpg',
    dur: '45 min',
    when: 'Today · 17:30 · 45 min',
    desc: 'A high-energy indoor cycling ride through climbs and sprints, set to music. Bring water and a towel.'
  }, {
    n: 'Yoga Flow',
    time: '19:00',
    ap: 'PM',
    coach: 'Coach Ada',
    cap: '9/16 booked',
    state: 'book',
    img: 'gym-kettlebells.jpg',
    dur: '60 min',
    when: 'Today · 19:00 · 60 min',
    desc: 'A calming vinyasa flow to stretch, breathe and unwind. Mats provided — just bring yourself.'
  }],
  thu: [{
    n: 'Boxing Conditioning',
    time: '18:00',
    ap: 'PM',
    coach: 'Coach Tobi',
    cap: '11/16 booked',
    state: 'book',
    img: 'gym-floor.jpg',
    dur: '50 min',
    when: 'Thu 12 · 18:00 · 50 min',
    desc: 'Pad work, footwork and conditioning rounds. Wraps recommended; gloves available to borrow.'
  }],
  fri: [{
    n: 'Sunrise HIIT',
    time: '06:30',
    ap: 'AM',
    coach: 'Coach Bisi',
    cap: '14/20 booked',
    state: 'book',
    img: 'gym-studio.jpg',
    dur: '45 min',
    when: 'Fri 13 · 06:30 · 45 min',
    desc: 'A fast, full-body HIIT circuit to start your day.'
  }, {
    n: 'Yoga Flow',
    time: '19:00',
    ap: 'PM',
    coach: 'Coach Ada',
    cap: '12/16 booked',
    state: 'booked',
    img: 'gym-kettlebells.jpg',
    dur: '60 min',
    when: 'Fri 13 · 19:00 · 60 min',
    desc: 'A calming vinyasa flow to stretch, breathe and unwind. Mats provided — just bring yourself.'
  }],
  sat: [{
    n: 'Open Floor',
    time: '08:00',
    ap: 'AM',
    coach: 'Self-guided',
    cap: 'Drop-in',
    state: 'book',
    img: 'gym-dumbbells.jpg',
    dur: '120 min',
    when: 'Sat 14 · 08:00 · open',
    desc: 'No class — the floor is yours. Coaches roam for form checks.'
  }],
  sun: []
};

// my bookings (upcoming)
let BOOKINGS = [{
  d: 11,
  dow: 'Wed',
  n: 'Spin Class',
  sub: 'Coach Tobi · 17:30 · today',
  key: 'wed'
}, {
  d: 13,
  dow: 'Fri',
  n: 'Yoga Flow',
  sub: 'Coach Ada · 19:00',
  key: 'fri'
}];
let curClass = null; // class open in detail
let curDay = 'wed'; // selected schedule day
let payPlan = {
  n: 'Quarterly',
  a: '37,999'
};

/* ───────────────────────── view nav ───────────────────────── */
function go(v) {
  $$('.view').forEach(x => x.classList.toggle('on', x.dataset.v === v));
  const tabMap = {
    classdetail: 'schedule',
    receipt: 'wallet',
    renew: 'wallet',
    notifications: 'home'
  };
  const tab = tabMap[v] || v;
  $$('.tabbar button, .rail button').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
  if (v === 'checkin') resetCi();
  if (v === 'renew') resetRenew();
  if (v === 'wallet') resetWallet();
  $('.scr').scrollTop = 0;
  lucide.createIcons();
}

/* ───────────────────────── check-in ───────────────────────── */
function checkIn() {
  $('#ciMain').style.display = 'none';
  $('#ciOk').classList.add('on');
  lucide.createIcons();
}
function resetCi() {
  $('#ciMain').style.display = 'block';
  $('#ciOk').classList.remove('on');
}

/* ───────────────────────── schedule ───────────────────────── */
function buildCalStrip() {
  $('#calStrip').innerHTML = WEEK.map(d => {
    const has = (SCHEDULE[d.key] || []).length > 0;
    const booked = BOOKINGS.some(b => b.key === d.key);
    return `<div class="cday${d.key === curDay ? ' on' : ''}" data-day="${d.key}" onclick="selectDay('${d.key}')">
      <span>${d.dow}</span><b>${d.date}</b>
      <i class="mk ${has ? '' : 'ghost'}" ${booked ? 'style="background:var(--gf-accent)"' : ''}></i></div>`;
  }).join('');
}
function selectDay(key) {
  curDay = key;
  $$('.cday').forEach(c => c.classList.toggle('on', c.dataset.day === key));
  renderDay(key);
}
function renderDay(key) {
  const list = SCHEDULE[key] || [];
  const d = WEEK.find(w => w.key === key);
  $('#dayLabel').textContent = d.today ? 'Today · Wed 11' : `${d.dow} ${d.date}`;
  const wrap = $('#dayClasses');
  if (!list.length) {
    wrap.innerHTML = `<div class="empty"><div class="eic"><i data-lucide="coffee"></i></div><h3>Rest day</h3><p>No classes scheduled. Recovery counts too.</p></div>`;
    lucide.createIcons();
    return;
  }
  wrap.innerHTML = list.map((c, i) => {
    const badge = c.state === 'booked' ? '<span class="gf-badge gf-badge-success" style="padding:5px 9px">Booked</span>' : c.few ? '<span class="gf-badge gf-badge-warning" style="padding:5px 9px">2 left</span>' : '';
    return `<div class="cls-card" onclick="openClass(this)"
        data-day="${key}" data-i="${i}"
        data-n="${c.n}" data-time="${c.time}" data-when="${c.when}" data-dur="${c.dur}"
        data-coach="${c.coach}" data-cap="${c.cap}" data-state="${c.state}" data-img="${c.img}" data-desc="${c.desc}">
      <div class="tm"><b>${c.time}</b><span>${c.ap}</span></div>
      <div class="info"><strong>${c.n}</strong><small>${c.coach} · ${c.cap}</small></div>
      ${badge}<i data-lucide="chevron-right" class="chev"></i></div>`;
  }).join('');
  lucide.createIcons();
}
function scheduleTab(t) {
  $$('#schedTabs button').forEach(b => b.classList.toggle('on', b.dataset.st === t));
  $('#schedCal').style.display = t === 'cal' ? 'block' : 'none';
  $('#schedBookings').style.display = t === 'book' ? 'block' : 'none';
  if (t === 'book') renderBookings();
}
function renderBookings() {
  const wrap = $('#bookingsList');
  if (!BOOKINGS.length) {
    wrap.innerHTML = `<div class="empty"><div class="eic"><i data-lucide="calendar-x"></i></div><h3>No upcoming bookings</h3><p>Browse the schedule and reserve your spot.</p><button class="gf-btn gf-btn-primary" onclick="scheduleTab('cal')">Browse classes</button></div>`;
    lucide.createIcons();
    return;
  }
  wrap.innerHTML = BOOKINGS.map((b, i) => `
    <div class="bkg" id="bkg-${i}">
      <div class="date"><b>${b.d}</b><span>${b.dow}</span></div>
      <div class="m"><strong>${b.n}</strong><small>${b.sub}</small></div>
      <button class="cancel" onclick="cancelBooking(${i})">Cancel</button>
    </div>`).join('');
  lucide.createIcons();
}
function cancelBooking(i) {
  const b = BOOKINGS[i];
  BOOKINGS.splice(i, 1);
  renderBookings();
  buildCalStrip();
  if (window.gfToast) gfToast(`Cancelled ${b.n}`);
}

/* ───────────────────────── class detail ───────────────────────── */
function openClass(el) {
  const d = el.dataset;
  curClass = {
    n: d.n,
    time: d.time,
    when: d.when,
    key: d.day,
    dow: (WEEK.find(w => w.key === d.day) || {}).dow,
    date: (WEEK.find(w => w.key === d.day) || {}).date,
    coach: d.coach
  };
  $('#cdName').textContent = d.n;
  $('#cdWhen').textContent = d.when;
  $('#cdImg').src = '../assets/' + d.img;
  $('#cdCoach').textContent = d.coach;
  $('#cdCoachAv').textContent = d.coach.replace('Coach ', '').charAt(0);
  $('#cdDesc').textContent = d.desc;
  $('#cdOkName').textContent = d.n;
  $('#cdOkWhen').textContent = d.time;
  $('#cdBadges').innerHTML = `<span class="gf-badge gf-badge-neutral">${d.time}</span><span class="gf-badge gf-badge-success">${d.cap}</span><span class="gf-badge gf-badge-brand">${d.dur}</span>`;
  const btn = $('#cdBookBtn');
  if (d.state === 'booked') {
    btn.className = 'gf-btn gf-btn-secondary gf-btn-full gf-btn-lg';
    btn.innerHTML = '<i data-lucide="check" style="width:18px;height:18px"></i> You\u2019re booked';
    btn.onclick = () => go('home');
  } else {
    btn.className = 'gf-btn gf-btn-primary gf-btn-full gf-btn-lg';
    btn.innerHTML = '<i data-lucide="calendar-plus" style="width:18px;height:18px"></i> Book your spot';
    btn.onclick = bookClass;
  }
  $('#cdMain').style.display = 'block';
  $('#cdOk').classList.remove('on');
  go('classdetail');
}
function bookClass() {
  if (curClass && !BOOKINGS.some(b => b.n === curClass.n && b.key === curClass.key)) {
    BOOKINGS.push({
      d: curClass.date,
      dow: curClass.dow,
      n: curClass.n,
      sub: `${curClass.coach} · ${curClass.time}`,
      key: curClass.key
    });
    buildCalStrip();
  }
  $('#cdMain').style.display = 'none';
  $('#cdOk').classList.add('on');
  lucide.createIcons();
}

/* ───────────────────────── renew ───────────────────────── */
function pick(el) {
  $$('.rplan').forEach(x => x.classList.remove('on'));
  el.classList.add('on');
  payPlan = {
    n: el.dataset.plan,
    a: el.dataset.amt
  };
  $('#payBtn').innerHTML = '<i data-lucide="credit-card" style="width:18px;height:18px"></i> Pay \u20a6' + payPlan.a + ' with Paystack';
  lucide.createIcons();
}
function pay() {
  $('#okPlan').textContent = payPlan.n;
  $('#renewPick').style.display = 'none';
  $('#renewOk').classList.add('on');
  lucide.createIcons();
}
function resetRenew() {
  $('#renewPick').style.display = 'block';
  $('#renewOk').classList.remove('on');
}

/* ───────────────────────── wallet ───────────────────────── */
function resetWallet() {
  $('#walletMain').style.display = 'block';
}
function toggleAutoDebit(el) {
  el.classList.toggle('on');
  if (window.gfToast) gfToast(el.classList.contains('on') ? 'Auto-debit on' : 'Auto-debit off');
}
function openReceipt(el) {
  const d = el.dataset;
  $('#rcAmt').textContent = (d.dir === 'in' ? '+\u20a6' : '\u20a6') + d.amt;
  $('#rcLabel').textContent = d.title;
  $('#rcList').innerHTML = `
    <div class="rrow"><span>Reference</span><b>${d.ref}</b></div>
    <div class="rrow"><span>Date</span><b>${d.date}</b></div>
    <div class="rrow"><span>Method</span><b>${d.method}</b></div>
    <div class="rrow"><span>Status</span><b style="color:var(--gf-brand)">Successful</b></div>
    <div class="rrow"><span>Amount</span><b>${d.dir === 'in' ? '+\u20a6' : '\u20a6'}${d.amt}</b></div>`;
  go('receipt');
}

/* ───────────────────────── notifications ───────────────────────── */
function updateBellNub() {
  const n = $$('.notif.unread').length;
  $$('.bell .nub').forEach(el => {
    el.textContent = n;
    el.classList.toggle('hide', n === 0);
  });
  $$('.nav-dot').forEach(el => el.style.display = n === 0 ? 'none' : 'block');
}
function openNotif(el) {
  el.classList.remove('unread');
  updateBellNub();
  const goto = el.dataset.go;
  if (goto) go(goto);
}
function markAllRead() {
  $$('.notif.unread').forEach(el => el.classList.remove('unread'));
  updateBellNub();
  if (window.gfToast) gfToast('All caught up');
}

/* ───────────────────────── device + theme + fit ───────────────────────── */
function setDevice(d) {
  $('#device').className = 'device ' + d;
  document.body.classList.toggle('expanded', d !== 'phone');
  document.body.classList.remove('dev-phone', 'dev-fold', 'dev-tablet');
  document.body.classList.add('dev-' + d);
  fit();
}
function fit() {
  const d = $('#device'),
    box = $('#fitbox');
  d.style.transform = 'none';
  const natW = d.offsetWidth,
    natH = d.offsetHeight;
  const availW = window.innerWidth - 40;
  const availH = window.innerHeight - 150;
  const r = Math.min(1, availW / natW, availH / natH);
  d.style.transform = 'scale(' + r + ')';
  box.style.width = natW * r + 'px';
  box.style.height = natH * r + 'px';
}
function setTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  try {
    localStorage.setItem('gf-theme', t);
  } catch (e) {}
  $('#themeBtn').innerHTML = '<i data-lucide="' + (t === 'light' ? 'moon' : 'sun') + '"></i>';
  lucide.createIcons();
}

/* ───────────────────────── init ───────────────────────── */
window.addEventListener('resize', fit);
document.addEventListener('DOMContentLoaded', () => {
  $$('#devSeg button').forEach(b => b.onclick = () => {
    $$('#devSeg button').forEach(x => x.classList.remove('on'));
    b.classList.add('on');
    setDevice(b.dataset.dev);
  });
  $('#themeBtn').onclick = () => setTheme(document.documentElement.getAttribute('data-theme') === 'light' ? 'dark' : 'light');
  try {
    const t = localStorage.getItem('gf-theme');
    if (t) setTheme(t);
  } catch (e) {}
  buildCalStrip();
  renderDay(curDay);
  updateBellNub();
  if (window.buildProto) buildProto('member');
  lucide.createIcons();
  fit();
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "revamp/member.js", error: String((e && e.message) || e) }); }

// revamp/mobile.js
try { (() => {
// Shared mobile-shell helpers: scale-to-fit, theme toggle, tab/view switching,
// and (new) phone / foldable / tablet device frames with an expanded side rail.
(function () {
  // apply persisted theme (shared 'gf-theme' key) before paint
  try {
    const t = localStorage.getItem('gf-theme');
    if (t) document.documentElement.setAttribute('data-theme', t);
  } catch (e) {}
  function fit() {
    const d = document.getElementById('device'),
      box = document.getElementById('fitbox');
    if (!d || !box) return;
    d.style.transform = 'none';
    const natW = d.offsetWidth,
      natH = d.offsetHeight;
    const r = Math.min(1, (window.innerWidth - 40) / natW, (window.innerHeight - 150) / natH);
    d.style.transform = 'scale(' + r + ')';
    box.style.width = natW * r + 'px';
    box.style.height = natH * r + 'px';
  }
  window.addEventListener('resize', fit);
  window.gfFit = fit;
  window.gfTheme = function (t) {
    document.documentElement.setAttribute('data-theme', t);
    try {
      localStorage.setItem('gf-theme', t);
    } catch (e) {}
    const b = document.getElementById('themeBtn');
    if (b) {
      b.innerHTML = '<i data-lucide="' + (t === 'light' ? 'moon' : 'sun') + '"></i>';
    }
    if (window.lucide) lucide.createIcons();
  };
  window.gfGo = function (v) {
    document.querySelectorAll('.view').forEach(x => x.classList.toggle('on', x.dataset.v === v));
    const tab = window.gfTabMap && window.gfTabMap[v] || v;
    document.querySelectorAll('.tabbar button, .rail button').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
    const scr = document.querySelector('.scr');
    if (scr) scr.scrollTop = 0;
    if (window.lucide) lucide.createIcons();
  };

  // ── device switching (phone / fold / tablet) ──
  window.gfDevice = function (d) {
    const dev = document.getElementById('device');
    if (!dev) return;
    dev.className = 'device ' + d;
    document.body.classList.toggle('expanded', d !== 'phone');
    document.body.classList.remove('dev-phone', 'dev-fold', 'dev-tablet');
    document.body.classList.add('dev-' + d);
    fit();
    if (window.lucide) lucide.createIcons();
  };

  // Build the expanded side rail from the existing bottom tab bar, and wrap
  // the scroll area so the rail can sit beside it on fold/tablet.
  function buildExpandedShell() {
    const dev = document.getElementById('device');
    if (!dev) return;
    const scr = dev.querySelector('.scr');
    const tabbar = dev.querySelector('.tabbar');
    if (!scr || dev.querySelector('.bodyrow')) return;

    // foldable crease (visible only on .device.fold)
    if (!dev.querySelector('.crease')) {
      const cr = document.createElement('div');
      cr.className = 'crease';
      dev.insertBefore(cr, dev.firstChild);
    }

    // gather nav items from the tab bar
    const btns = tabbar ? [...tabbar.querySelectorAll('button')] : [];
    const navHtml = btns.map(b => {
      const tab = b.dataset.tab || '';
      const onclick = b.getAttribute('onclick') || '';
      const iconEl = b.querySelector('i');
      const icon = iconEl ? iconEl.getAttribute('data-lucide') : 'circle';
      const label = (b.textContent || '').trim();
      const on = b.classList.contains('on') ? ' on' : '';
      return `<button class="${on}" data-tab="${tab}" onclick="${onclick}"><i data-lucide="${icon}"></i> ${label}</button>`;
    }).join('');

    // foot identity — derive from the .controls label + first avatar letter
    const lblEl = document.querySelector('.controls .lbl');
    const role = lblEl ? lblEl.textContent.trim() : 'Account';
    const avEl = dev.querySelector('.mhead .gf-avatar');
    const letter = avEl ? avEl.textContent.trim().charAt(0) || 'G' : 'G';
    const rail = document.createElement('aside');
    rail.className = 'rail';
    rail.innerHTML = `<div class="rail-brand"><img src="../assets/logomark-v2.svg" alt="" /><span>Gym<em>Flow</em></span></div>` + navHtml + `<div class="rail-spacer"></div>` + `<div class="rail-foot"><span class="gf-avatar gf-avatar-sm">${letter}</span><div style="min-width:0"><strong>${role}</strong><small>GymFlow</small></div></div>`;
    const bodyrow = document.createElement('div');
    bodyrow.className = 'bodyrow';
    dev.insertBefore(bodyrow, scr);
    bodyrow.appendChild(rail);
    bodyrow.appendChild(scr);
  }

  // Inject the device segmented control into the top .controls bar.
  function injectDeviceControl() {
    const controls = document.querySelector('.controls');
    if (!controls || controls.querySelector('.seg-ctrl')) return;
    const seg = document.createElement('div');
    seg.className = 'seg-ctrl';
    seg.id = 'devSeg';
    seg.innerHTML = `<button class="on" data-dev="phone"><i data-lucide="smartphone"></i> Phone</button>` + `<button data-dev="fold"><i data-lucide="tablet-smartphone"></i> Fold</button>` + `<button data-dev="tablet"><i data-lucide="tablet"></i> Tablet</button>`;
    const lbl = controls.querySelector('.lbl');
    if (lbl) lbl.after(seg);else controls.prepend(seg);
    seg.querySelectorAll('button').forEach(b => b.onclick = () => {
      seg.querySelectorAll('button').forEach(x => x.classList.remove('on'));
      b.classList.add('on');
      gfDevice(b.dataset.dev);
    });
  }
  document.addEventListener('DOMContentLoaded', function () {
    const tb = document.getElementById('themeBtn');
    if (tb) {
      const cur = document.documentElement.getAttribute('data-theme') || 'light';
      tb.innerHTML = '<i data-lucide="' + (cur === 'light' ? 'moon' : 'sun') + '"></i>';
      tb.onclick = () => gfTheme(document.documentElement.getAttribute('data-theme') === 'light' ? 'dark' : 'light');
    }
    buildExpandedShell();
    injectDeviceControl();
    document.body.classList.add('dev-phone');
    const dev = document.getElementById('device');
    if (dev && !/\b(phone|fold|tablet)\b/.test(dev.className)) dev.className = 'device phone';
    fit();
    if (window.lucide) lucide.createIcons();
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "revamp/mobile.js", error: String((e && e.message) || e) }); }

// revamp/notifications-panel.js
try { (() => {
/* ============================================================================
   GymFlow — shared notifications panel (desktop portals).
   Self-initializing. Injected by admin/instructor/superadmin shells.
   Replaces the topbar bell's static dot with a live count + a slide-over
   panel of role-appropriate notifications.
   ============================================================================ */
(function () {
  if (window.__gfNotifReady) return;
  window.__gfNotifReady = true;

  /* role-specific feeds */
  const FEEDS = {
    admin: [{
      g: 'Today',
      items: [{
        t: 'reminder',
        ic: 'alert-triangle',
        cls: 'warn',
        title: '3 memberships expired today',
        body: 'Chidi O., Maryam S. and 1 more need follow-up. Send a renewal nudge?',
        time: '9:12 AM',
        unread: true
      }, {
        t: 'class',
        ic: 'calendar-clock',
        cls: 'brand',
        title: 'Spin Class is 92% filling up',
        body: '22 of 24 booked for 17:30 with Coach Tobi. Open a waitlist?',
        time: '8:40 AM',
        unread: true
      }, {
        t: 'pay',
        ic: 'wallet',
        cls: 'info',
        title: 'Paystack payout settled',
        body: '₦248,500 landed in your GTBank account ending 4471.',
        time: '7:05 AM',
        unread: true
      }]
    }, {
      g: 'Earlier',
      items: [{
        t: 'member',
        ic: 'user-plus',
        cls: 'brand',
        title: 'New member: Chidi O.',
        body: 'Joined the Growth plan via powerhouse.gymflow.ng.',
        time: 'Yesterday'
      }, {
        t: 'system',
        ic: 'scan-line',
        cls: 'muted',
        title: '5 check-ins flagged',
        body: 'Members tried to check in with an expired plan.',
        time: 'Yesterday'
      }]
    }],
    instructor: [{
      g: 'Today',
      items: [{
        t: 'class',
        ic: 'bike',
        cls: 'brand',
        title: 'Spin Class in 2 hours',
        body: '22 members booked for 17:30. Studio 2 is reserved for you.',
        time: '3:30 PM',
        unread: true
      }, {
        t: 'member',
        ic: 'dumbbell',
        cls: 'accent',
        title: 'New PT client: Ada B.',
        body: 'Booked a 6-session strength block starting Monday.',
        time: '11:20 AM',
        unread: true
      }, {
        t: 'pay',
        ic: 'wallet',
        cls: 'info',
        title: 'Payout on the way',
        body: '₦86,400 for this week\u2019s classes — arriving Fri.',
        time: '9:00 AM',
        unread: true
      }]
    }, {
      g: 'Earlier',
      items: [{
        t: 'class',
        ic: 'calendar-clock',
        cls: 'muted',
        title: 'Class moved',
        body: 'Yoga Flow shifted to 19:30 on Fri at the studio\u2019s request.',
        time: 'Yesterday'
      }]
    }],
    superadmin: [{
      g: 'Today',
      items: [{
        t: 'gym',
        ic: 'building-2',
        cls: 'brand',
        title: 'New gym onboarded',
        body: 'Lekki Fitness Collective went live on lekkifitness.gymflow.ng.',
        time: '10:48 AM',
        unread: true
      }, {
        t: 'rev',
        ic: 'trending-up',
        cls: 'accent',
        title: 'Platform MRR crossed ₦12M',
        body: 'Up 8.4% month-on-month across 47 active gyms.',
        time: '8:15 AM',
        unread: true
      }, {
        t: 'risk',
        ic: 'alert-triangle',
        cls: 'warn',
        title: '2 gyms past due',
        body: 'Platform fee overdue for Apex Arena and FitHub Abuja.',
        time: '7:30 AM',
        unread: true
      }]
    }, {
      g: 'Earlier',
      items: [{
        t: 'support',
        ic: 'life-buoy',
        cls: 'info',
        title: 'Support ticket escalated',
        body: 'Paystack reconciliation issue raised by Powerhouse Fitness.',
        time: 'Yesterday'
      }]
    }]
  };
  function detectRole() {
    if (document.body && document.body.dataset.gfRole) return document.body.dataset.gfRole;
    if (window.GF_NOTIF_ROLE) return window.GF_NOTIF_ROLE;
    if (document.getElementById('admSidebar')) return 'admin';
    if (document.getElementById('coachSidebar')) return 'instructor';
    if (document.getElementById('saSidebar')) return 'superadmin';
    return 'admin';
  }
  function injectCss() {
    if (document.getElementById('gfNotifCss')) return;
    const s = document.createElement('style');
    s.id = 'gfNotifCss';
    s.textContent = `
      .bell { position: relative; }
      .bell::after { display: none !important; }
      .gfnp-nub { position:absolute; top:5px; right:5px; min-width:16px; height:16px; padding:0 4px; border-radius:99px;
        background:var(--gf-danger); color:#fff; font-family:var(--gf-font-display); font-weight:800; font-size:0.6rem;
        display:grid; place-items:center; border:2px solid var(--gf-surface); line-height:1; pointer-events:none; }
      .gfnp-nub.hide { display:none; }
      .gfnp-backdrop { position:fixed; inset:0; background:rgba(0,0,0,0.5); -webkit-backdrop-filter:blur(2px); backdrop-filter:blur(2px);
        opacity:0; pointer-events:none; transition:opacity .25s var(--gf-ease-std); z-index:1200; }
      .gfnp-backdrop.open { opacity:1; pointer-events:auto; }
      .gfnp { position:fixed; top:0; right:0; height:100%; width:384px; max-width:92vw; background:var(--gf-surface);
        border-left:1px solid var(--gf-border); box-shadow:var(--gf-shadow-lg); transform:translateX(102%);
        transition:transform .32s var(--gf-ease-out); z-index:1201; display:flex; flex-direction:column; }
      .gfnp.open { transform:none; }
      .gfnp-head { display:flex; align-items:center; gap:12px; padding:18px 20px 16px; border-bottom:1px solid var(--gf-border); flex-shrink:0; }
      .gfnp-head h3 { font-family:var(--gf-font-display); font-weight:800; font-size:1.1rem; letter-spacing:-0.01em; margin:0; flex:1; }
      .gfnp-head .gfnp-mark { background:none; border:none; color:var(--gf-brand); font-family:var(--gf-font-display); font-weight:600; font-size:0.8rem; cursor:pointer; padding:6px 8px; border-radius:var(--gf-radius-xs); white-space:nowrap; }
      .gfnp-head .gfnp-mark:hover { background:var(--gf-brand-soft); }
      .gfnp-head .gfnp-x { width:34px; height:34px; border-radius:var(--gf-radius-xs); border:1px solid var(--gf-border); background:var(--gf-elevated); color:var(--gf-text-secondary); display:grid; place-items:center; cursor:pointer; flex-shrink:0; }
      .gfnp-head .gfnp-x:hover { color:var(--gf-text); }
      .gfnp-head .gfnp-x i { width:16px; height:16px; }
      .gfnp-body { flex:1; overflow-y:auto; padding:6px 16px 28px; }
      .gfnp-g { font-family:var(--gf-font-display); font-weight:800; font-size:0.7rem; text-transform:uppercase; letter-spacing:0.06em; color:var(--gf-text-muted); margin:18px 0 9px; }
      .gfnp-i { display:flex; gap:12px; padding:13px; border:1px solid var(--gf-border); border-radius:var(--gf-radius); background:var(--gf-surface); margin-bottom:8px; cursor:pointer; transition:border-color var(--gf-t-fast); position:relative; }
      .gfnp-i:hover { border-color:var(--gf-border-light); }
      .gfnp-i.unread { background:var(--gf-brand-soft); border-color:var(--gf-border-glow); }
      .gfnp-i .nic { width:40px; height:40px; border-radius:12px; display:grid; place-items:center; flex-shrink:0; }
      .gfnp-i .nic i { width:18px; height:18px; }
      .gfnp-i .nic.brand { background:var(--gf-brand-soft); color:var(--gf-brand); }
      .gfnp-i .nic.accent { background:var(--gf-accent-soft); color:var(--gf-accent-dark); }
      .gfnp-i .nic.info { background:var(--gf-info-soft); color:var(--gf-info); }
      .gfnp-i .nic.warn { background:var(--gf-warning-soft); color:var(--gf-warning); }
      .gfnp-i .nic.muted { background:var(--gf-elevated); color:var(--gf-text-secondary); }
      .gfnp-i .m { flex:1; min-width:0; }
      .gfnp-i .m strong { font-family:var(--gf-font-display); font-size:0.86rem; font-weight:700; display:block; line-height:1.3; }
      .gfnp-i .m p { color:var(--gf-text-secondary); font-size:0.79rem; margin:3px 0 0; line-height:1.45; }
      .gfnp-i .m .nt { color:var(--gf-text-muted); font-size:0.69rem; margin-top:6px; display:block; }
      .gfnp-i .ud { position:absolute; top:14px; right:13px; width:8px; height:8px; border-radius:50%; background:var(--gf-brand); }
      .gfnp-i:not(.unread) .ud { display:none; }
      .gfnp-foot { padding:14px 20px; border-top:1px solid var(--gf-border); flex-shrink:0; }
      .gfnp-foot a { color:var(--gf-text-secondary); font-family:var(--gf-font-display); font-weight:600; font-size:0.8rem; text-decoration:none; display:flex; align-items:center; justify-content:center; gap:7px; }
      .gfnp-foot a:hover { color:var(--gf-text); }
      .gfnp-foot a i { width:15px; height:15px; }
    `;
    document.head.appendChild(s);
  }
  let feed, panel, backdrop;
  function render() {
    const body = panel.querySelector('.gfnp-body');
    body.innerHTML = feed.map((grp, gi) => `
      <div class="gfnp-g">${grp.g}</div>
      ${grp.items.map((it, ii) => `
        <div class="gfnp-i ${it.unread ? 'unread' : ''}" data-g="${gi}" data-i="${ii}">
          <span class="nic ${it.cls}"><i data-lucide="${it.ic}"></i></span>
          <div class="m"><strong>${it.title}</strong><p>${it.body}</p><span class="nt">${it.time}</span></div>
          <span class="ud"></span>
        </div>`).join('')}
    `).join('');
    if (window.lucide) lucide.createIcons();
  }
  function unreadCount() {
    return feed.reduce((n, g) => n + g.items.filter(i => i.unread).length, 0);
  }
  function syncNub() {
    const n = unreadCount();
    document.querySelectorAll('.bell').forEach(b => {
      let nub = b.querySelector('.gfnp-nub');
      if (!nub) {
        nub = document.createElement('span');
        nub.className = 'gfnp-nub';
        b.appendChild(nub);
      }
      nub.textContent = n;
      nub.classList.toggle('hide', n === 0);
    });
  }
  function open() {
    backdrop.classList.add('open');
    panel.classList.add('open');
  }
  function close() {
    backdrop.classList.remove('open');
    panel.classList.remove('open');
  }
  function build() {
    injectCss();
    feed = FEEDS[detectRole()] || FEEDS.admin;
    backdrop = document.createElement('div');
    backdrop.className = 'gfnp-backdrop';
    backdrop.onclick = close;
    panel = document.createElement('aside');
    panel.className = 'gfnp';
    panel.innerHTML = `
      <div class="gfnp-head">
        <h3>Notifications</h3>
        <button class="gfnp-mark">Mark all read</button>
        <button class="gfnp-x" aria-label="Close"><i data-lucide="x"></i></button>
      </div>
      <div class="gfnp-body"></div>
      <div class="gfnp-foot"><a href="#"><i data-lucide="settings"></i> Notification settings</a></div>`;
    document.body.appendChild(backdrop);
    document.body.appendChild(panel);
    panel.querySelector('.gfnp-x').onclick = close;
    panel.querySelector('.gfnp-mark').onclick = e => {
      e.stopPropagation();
      feed.forEach(g => g.items.forEach(i => i.unread = false));
      render();
      syncNub();
      if (window.gfToast) gfToast('All caught up');
    };
    panel.querySelector('.gfnp-body').addEventListener('click', e => {
      const row = e.target.closest('.gfnp-i');
      if (!row) return;
      const it = feed[+row.dataset.g].items[+row.dataset.i];
      if (it.unread) {
        it.unread = false;
        row.classList.remove('unread');
        syncNub();
      }
    });
    render();
    syncNub();

    // delegate bell clicks (bell is injected by the shell, possibly after us)
    document.addEventListener('click', e => {
      const b = e.target.closest('.bell');
      if (!b) return;
      e.preventDefault();
      e.stopPropagation();
      panel.classList.contains('open') ? close() : open();
    }, true);
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') close();
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', build);else build();
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "revamp/notifications-panel.js", error: String((e && e.message) || e) }); }

// revamp/proto.js
try { (() => {
// Shared prototype role-switcher. Call buildProto('<current>') after DOM ready.
function buildProto(current) {
  const items = [{
    p: 'marketing',
    href: 'marketing.html',
    icon: 'globe',
    label: 'Site'
  }, {
    p: 'login',
    href: 'login.html',
    icon: 'log-in',
    label: 'Login'
  }, {
    p: 'member',
    href: 'member.html',
    icon: 'user',
    label: 'Member'
  }, {
    p: 'admin',
    href: 'admin.html',
    icon: 'layout-dashboard',
    label: 'Admin'
  }, {
    p: 'instructor',
    href: 'instructor.html',
    icon: 'graduation-cap',
    label: 'Coach'
  }, {
    p: 'superadmin',
    href: 'superadmin.html',
    icon: 'shield-check',
    label: 'Platform'
  }];
  const el = document.getElementById('proto');
  if (!el) return;
  el.innerHTML = '<span class="lbl-tag">Preview</span>' + items.map(i => `<a href="${i.href}" class="${i.p === current ? 'on' : ''}"><i data-lucide="${i.icon}"></i><span>${i.label}</span></a>`).join('');
  if (window.lucide) lucide.createIcons();
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "revamp/proto.js", error: String((e && e.message) || e) }); }

// revamp/superadmin-shell.js
try { (() => {
// ── GymFlow superadmin shell: sidebar + topbar for platform pages ──
// Usage: <aside id="saSidebar"></aside> ... <header id="saTop"></header>
//   saShell('gyms', { search:'Search…', action:{label,icon,href} });
(function () {
  try {
    const t = localStorage.getItem('gf-theme');
    if (t) document.documentElement.setAttribute('data-theme', t);
  } catch (e) {}
  const NAV = [{
    s: 'Platform',
    items: [{
      k: 'overview',
      label: 'Overview',
      icon: 'layout-dashboard',
      href: 'superadmin.html'
    }, {
      k: 'gyms',
      label: 'Gyms',
      icon: 'building-2',
      href: 'superadmin-gyms.html'
    }, {
      k: 'members',
      label: 'All members',
      icon: 'users',
      href: 'superadmin-members.html'
    }, {
      k: 'revenue',
      label: 'Revenue',
      icon: 'line-chart',
      href: 'superadmin-revenue.html'
    }]
  }, {
    s: 'Operations',
    items: [{
      k: 'onboard',
      label: 'Onboard gym',
      icon: 'user-plus',
      href: 'superadmin-onboard.html'
    }, {
      k: 'audit',
      label: 'Audit log',
      icon: 'shield-check',
      href: 'superadmin-audit.html'
    }, {
      k: 'support',
      label: 'Support',
      icon: 'life-buoy',
      href: 'superadmin-support.html'
    }, {
      k: 'settings',
      label: 'Settings',
      icon: 'settings',
      href: 'superadmin-settings.html'
    }]
  }];
  if (!document.getElementById('saShellCss')) {
    const css = document.createElement('style');
    css.id = 'saShellCss';
    css.textContent = `
      .sb-role { display:flex; align-items:center; gap:10px; margin-top:14px; padding:8px; border-radius:var(--gf-radius-sm); background:var(--gf-elevated); border:1px solid var(--gf-border); }
      .sb-role .gf-avatar { background:var(--gf-info-soft); color:var(--gf-info); border-color:rgba(64,128,255,0.25); }
      .sb-role small { color:var(--gf-text-muted); font-size:0.66rem; display:block; }
      .sb-role strong { font-family:var(--gf-font-display); font-size:0.85rem; }
      .pill-plat { display:inline-flex; align-items:center; gap:6px; font-family:var(--gf-font-display); font-weight:700; font-size:0.66rem; text-transform:uppercase; letter-spacing:0.06em; color:var(--gf-info); background:var(--gf-info-soft); border:1px solid rgba(64,128,255,0.25); padding:3px 9px; border-radius:var(--gf-radius-pill); }
      .bell { position:relative; }
      .bell::after { content:''; position:absolute; top:9px; right:10px; width:7px; height:7px; border-radius:50%; background:var(--gf-danger); border:2px solid var(--gf-elevated); }
      .page-h2 { display:flex; align-items:flex-end; justify-content:space-between; gap:16px; flex-wrap:wrap; margin-bottom:22px; }
      .page-h2 h1 { font-family:var(--gf-font-display); font-size:clamp(1.5rem,2.4vw,2rem); font-weight:800; letter-spacing:-0.03em; line-height:1.15; margin:6px 0 0; }
      .page-h2 p { margin:6px 0 0; color:var(--gf-text-secondary); font-size:0.9rem; }
      .kpis { display:grid; grid-template-columns:repeat(4,1fr); gap:14px; margin-bottom:18px; }
      .kpi { background:var(--gf-surface); border:1px solid var(--gf-border); border-radius:var(--gf-radius); padding:18px; transition:all var(--gf-t); }
      .kpi:hover { transform:translateY(-3px); border-color:var(--gf-border-light); box-shadow:var(--gf-shadow); }
      .kpi-top { display:flex; align-items:center; justify-content:space-between; margin-bottom:12px; }
      .kpi-ic { width:38px; height:38px; border-radius:11px; display:grid; place-items:center; }
      .kpi-ic i { width:19px; height:19px; }
      .kpi-val { font-family:var(--gf-font-display); font-size:2rem; font-weight:800; letter-spacing:-0.03em; line-height:1; }
      .kpi-lbl { color:var(--gf-text-muted); font-size:0.8125rem; margin-top:6px; }
      .gname { display:flex; align-items:center; gap:11px; }
      .gname .sq { width:34px; height:34px; border-radius:10px; display:grid; place-items:center; font-family:var(--gf-font-display); font-weight:800; font-size:0.85rem; color:#fff; flex-shrink:0; }
      .gname strong { font-family:var(--gf-font-display); font-weight:600; display:block; font-size:0.875rem; }
      .gname small { color:var(--gf-text-muted); font-size:0.72rem; }
      .naira { font-variant-numeric:tabular-nums; font-weight:600; font-family:var(--gf-font-display); }
    `;
    document.head.appendChild(css);
  }
  window.saShell = function (active, topOpts) {
    topOpts = topOpts || {};
    const sb = document.getElementById('saSidebar');
    const top = document.getElementById('saTop');
    if (sb) {
      sb.innerHTML = `
        <div class="gf-sidebar-header">
          <a class="brand" href="marketing.html" style="text-decoration:none"><img class="mark-sm" src="../assets/logomark-v2.svg" alt="" /><span class="brand-tx">Gym<em>Flow</em></span></a>
          <div class="sb-role"><span class="gf-avatar gf-avatar-sm">S</span><div><strong>Samuel A.</strong><small>Platform admin</small></div></div>
        </div>
        <nav class="gf-sidebar-nav">
          ${NAV.map(g => `<span class="gf-sidebar-section">${g.s}</span>${g.items.map(i => `<a class="gf-nav-item${i.k === active ? ' active' : ''}" href="${i.href}"><i data-lucide="${i.icon}"></i><span>${i.label}</span></a>`).join('')}`).join('')}
        </nav>
        <div class="gf-sidebar-footer"><a class="gf-nav-item" href="login.html"><i data-lucide="log-out"></i><span>Sign out</span></a></div>`;
    }
    if (top) {
      const act = topOpts.action;
      top.innerHTML = `
        <div class="search" style="flex:1;max-width:440px"><i data-lucide="search"></i><input placeholder="${topOpts.search || 'Search…'}" /></div>
        <div style="flex:1"></div>
        <span class="pill-plat"><i data-lucide="shield" style="width:13px;height:13px"></i> Superadmin</span>
        <button class="icon-btn" data-theme-toggle data-theme-icon title="Toggle theme"><i data-lucide="moon"></i></button>
        <button class="icon-btn bell"><i data-lucide="bell"></i></button>
        ${act ? `<a class="gf-btn gf-btn-primary" href="${act.href || '#'}"><i data-lucide="${act.icon}" style="width:16px;height:16px"></i> ${act.label}</a>` : ''}`;
    }
    if (window.lucide) lucide.createIcons();
    if (window.gfSyncThemeIcons) window.gfSyncThemeIcons();
    if (!document.getElementById('gfNotifJs')) {
      const ns = document.createElement('script');
      ns.id = 'gfNotifJs';
      ns.src = 'notifications-panel.js';
      document.body.appendChild(ns);
    }
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "revamp/superadmin-shell.js", error: String((e && e.message) || e) }); }

// revamp/theme.js
try { (() => {
// Shared, persisted light/dark theme. Load on every page (before other scripts).
(function () {
  const KEY = 'gf-theme';
  const stored = localStorage.getItem(KEY);
  if (stored) document.documentElement.setAttribute('data-theme', stored);
  function syncIcons() {
    const t = document.documentElement.getAttribute('data-theme') || 'dark';
    document.querySelectorAll('[data-theme-icon]').forEach(b => {
      b.innerHTML = '<i data-lucide="' + (t === 'dark' ? 'sun' : 'moon') + '"></i>';
    });
    if (window.lucide) lucide.createIcons();
  }
  window.gfSetTheme = function (t) {
    document.documentElement.setAttribute('data-theme', t);
    localStorage.setItem(KEY, t);
    syncIcons();
  };
  window.gfToggleTheme = function () {
    const cur = document.documentElement.getAttribute('data-theme') || 'dark';
    window.gfSetTheme(cur === 'dark' ? 'light' : 'dark');
  };
  // delegate clicks from any [data-theme-toggle] control
  document.addEventListener('click', function (e) {
    const b = e.target.closest('[data-theme-toggle]');
    if (b) {
      e.preventDefault();
      window.gfToggleTheme();
    }
  });
  document.addEventListener('DOMContentLoaded', syncIcons);
  window.gfSyncThemeIcons = syncIcons;

  // Auto-inject a floating theme toggle on pages that don't already have one.
  function injectFab() {
    if (!document.body) return;
    if (document.querySelector('[data-theme-toggle], #admTheme, #themeBtn, .theme-fab')) return;
    const b = document.createElement('button');
    b.className = 'theme-fab';
    b.setAttribute('data-theme-toggle', '');
    b.setAttribute('data-theme-icon', '');
    b.title = 'Toggle theme';
    b.innerHTML = '<i data-lucide="moon"></i>';
    b.style.cssText = 'position:fixed;left:18px;bottom:18px;z-index:510;width:42px;height:42px;border-radius:50%;border:1px solid var(--gf-border);background:var(--gf-surface);color:var(--gf-text);display:grid;place-items:center;cursor:pointer;box-shadow:var(--gf-shadow-md);';
    document.body.appendChild(b);
    syncIcons();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', injectFab);else injectFab();
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "revamp/theme.js", error: String((e && e.message) || e) }); }

// revamp/ui.js
try { (() => {
/* ============================================================================
   GymFlow — shared popup system + intent router.
   • gfUI.modal / drawer / confirm / form  — on-brand popups
   • a single capture-phase click router turns every previously-dead
     "— prototype" button / link / list-row into a believable popup.
   Loaded on every page (via wire.js and admin-shell.js).
   ============================================================================ */
(function () {
  if (window.gfUI) return;

  // ── stylesheet ──
  if (!document.getElementById('gfUiCss')) {
    const l = document.createElement('link');
    l.id = 'gfUiCss';
    l.rel = 'stylesheet';
    l.href = 'ui.css';
    document.head.appendChild(l);
  }
  const ic = () => {
    if (window.lucide) lucide.createIcons();
  };

  // ── toast (reuse the shared one if present) ──
  function toast(msg) {
    if (window.gfToast && window.gfToast !== toast) return window.gfToast(msg);
    let t = document.getElementById('gfToast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'gfToast';
      t.className = 'toast';
      t.innerHTML = '<i data-lucide="check-circle-2"></i><span></span>';
      document.body.appendChild(t);
    }
    t.querySelector('span').textContent = msg;
    ic();
    t.classList.add('show');
    clearTimeout(t._tm);
    t._tm = setTimeout(() => t.classList.remove('show'), 2200);
  }

  // ── host ──
  let bg = null;
  function host() {
    if (bg) return bg;
    bg = document.createElement('div');
    bg.className = 'gfui-bg';
    bg.addEventListener('click', e => {
      if (e.target === bg) close();
    });
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape') close();
    });
    document.body.appendChild(bg);
    return bg;
  }
  function close() {
    if (bg) bg.classList.remove('open');
    document.querySelectorAll('.gfui-drawer.open').forEach(d => d.classList.remove('open'));
  }
  function headHTML(o) {
    const icon = o.icon ? `<span class="gfui-ic ${o.tone || ''}"><i data-lucide="${o.icon}"></i></span>` : '';
    const sub = o.subtitle ? `<p>${o.subtitle}</p>` : '';
    return `<div class="gfui-h">${icon}<div class="gfui-tt"><h3>${o.title || ''}</h3>${sub}</div><button class="gfui-x" data-gfui-close aria-label="Close"><i data-lucide="x"></i></button></div>`;
  }
  function footHTML(actions) {
    if (!actions || !actions.length) return '';
    return `<div class="gfui-f">${actions.map((a, i) => `<button class="gf-btn ${a.kind || 'gf-btn-secondary'}" data-gfui-act="${i}">${a.icon ? `<i data-lucide="${a.icon}" style="width:16px;height:16px"></i> ` : ''}${a.label}</button>`).join('')}</div>`;
  }
  function bindActions(root, actions) {
    root.querySelectorAll('[data-gfui-close]').forEach(b => b.onclick = close);
    (actions || []).forEach((a, i) => {
      const btn = root.querySelector(`[data-gfui-act="${i}"]`);
      if (btn) btn.onclick = () => {
        const keep = a.onClick && a.onClick();
        if (!keep && a.close !== false) close();
      };
    });
  }

  // ── modal ──
  function modal(o) {
    host();
    bg.innerHTML = '';
    const m = document.createElement('div');
    m.className = 'gfui-modal';
    m.innerHTML = headHTML(o) + `<div class="gfui-b">${o.bodyHTML || ''}</div>` + footHTML(o.actions);
    bg.appendChild(m);
    bindActions(m, o.actions);
    if (o.onMount) o.onMount(m);
    requestAnimationFrame(() => bg.classList.add('open'));
    ic();
    return m;
  }

  // ── drawer ──
  function drawer(o) {
    host();
    bg.innerHTML = '';
    // backdrop stays for click-out; drawer is a sibling fixed element
    document.querySelectorAll('.gfui-drawer').forEach(d => d.remove());
    const d = document.createElement('aside');
    d.className = 'gfui-drawer';
    d.innerHTML = headHTML(o) + `<div class="gfui-b">${o.bodyHTML || ''}</div>` + footHTML(o.actions);
    document.body.appendChild(d);
    bindActions(d, o.actions);
    requestAnimationFrame(() => {
      bg.classList.add('open');
      d.classList.add('open');
    });
    ic();
    return d;
  }

  // ── confirm ──
  function confirm(o) {
    return modal({
      title: o.title,
      subtitle: o.subtitle,
      icon: o.icon || (o.danger ? 'alert-triangle' : 'help-circle'),
      tone: o.danger ? 'danger' : '',
      bodyHTML: `<p class="gfui-text">${o.body || ''}</p>`,
      actions: [{
        label: o.cancelLabel || 'Cancel',
        kind: 'gf-btn-ghost'
      }, {
        label: o.confirmLabel || 'Confirm',
        kind: o.danger ? 'gf-btn-danger' : 'gf-btn-primary',
        icon: o.confirmIcon,
        onClick: () => {
          if (o.onConfirm) o.onConfirm();else toast(o.toast || 'Done');
        }
      }]
    });
  }

  // ── form ──
  function fieldHTML(f) {
    const lab = f.label ? `<label class="gf-form-label">${f.label}</label>` : '';
    let ctrl;
    if (f.type === 'select') ctrl = `<select class="gf-select" data-f="${f.name || ''}">${(f.options || []).map(o => `<option>${o}</option>`).join('')}</select>`;else if (f.type === 'textarea') ctrl = `<textarea class="gf-textarea" data-f="${f.name || ''}" placeholder="${f.placeholder || ''}" style="min-height:84px"></textarea>`;else if (f.type === 'naira') ctrl = `<div class="gf-naira-input"><input class="gf-input" data-f="${f.name || ''}" placeholder="${f.placeholder || '0'}" inputmode="numeric" /></div>`;else ctrl = `<input class="gf-input" type="${f.type || 'text'}" data-f="${f.name || ''}" placeholder="${f.placeholder || ''}" ${f.value ? `value="${f.value}"` : ''} />`;
    return `<div class="gf-form-group" style="${f.half ? '' : 'grid-column:1/-1'}">${lab}${ctrl}</div>`;
  }
  function form(o) {
    const fields = o.fields || [];
    const body = `<div class="gfui-grid2">${fields.map(fieldHTML).join('')}</div>` + (o.note ? `<div class="gfui-note"><i data-lucide="${o.noteIcon || 'shield-check'}"></i> ${o.note}</div>` : '');
    return modal({
      title: o.title,
      subtitle: o.subtitle,
      icon: o.icon || 'plus',
      tone: o.tone,
      bodyHTML: body,
      actions: [{
        label: 'Cancel',
        kind: 'gf-btn-ghost'
      }, {
        label: o.submitLabel || 'Save',
        kind: 'gf-btn-primary',
        icon: o.submitIcon || 'check',
        onClick: () => {
          if (o.onSubmit) o.onSubmit();else toast(o.success || 'Saved');
        }
      }]
    });
  }
  window.gfUI = {
    modal,
    drawer,
    confirm,
    form,
    close,
    toast
  };
  window.gfToast = window.gfToast || toast;

  /* ════════════════════════ intent router ════════════════════════ */
  const RX = {
    danger: /\b(delete|remove|suspend|deactivate|revoke|disable|terminate|block|end\b|refund)\b/i,
    create: /\b(add|new|create|invite|onboard|register|enrol|log\b|raise|generate)\b/i,
    exp: /\b(export|download|statement|\.pdf|\.csv|report)\b/i,
    send: /\b(remind|nudge|send|notify|message|whatsapp|broadcast|resend|email\b|call\b)\b/i,
    edit: /\b(edit|manage|configure|update|change|customi|set up|setup|adjust)\b/i,
    view: /\b(view|details|see all|open|profile|inspect)\b/i
  };
  function clean(el) {
    const s = (el.getAttribute('aria-label') || el.title || el.textContent || '').trim().replace(/\s+/g, ' ');
    return s ? s.slice(0, 60) : 'Action';
  }

  // field presets keyed by the noun found in the label
  function formSpec(label) {
    const l = label.toLowerCase();
    const base = (title, icon, fields, submitLabel, success) => ({
      title,
      icon,
      fields,
      submitLabel,
      success
    });
    if (/\bmember\b/.test(l)) return base('Add member', 'user-plus', [{
      label: 'Full name',
      name: 'n',
      placeholder: 'e.g. Chidi Okeke'
    }, {
      label: 'Phone',
      name: 'p',
      placeholder: '0801 234 5678',
      half: true
    }, {
      label: 'Email',
      name: 'e',
      placeholder: 'name@mail.com',
      half: true
    }, {
      label: 'Plan',
      name: 'plan',
      type: 'select',
      options: ['Monthly — ₦13,999', 'Quarterly — ₦37,999', 'Annual — ₦119,999']
    }, {
      label: 'Start date',
      name: 'd',
      type: 'date',
      half: true
    }, {
      label: 'Referred by',
      name: 'r',
      placeholder: 'Optional',
      half: true
    }], 'Create member', 'Member added');
    if (/\bclass|session\b/.test(l)) return base(/session/.test(l) ? 'New PT session' : 'New class', 'calendar-plus', [{
      label: 'Name',
      name: 'n',
      placeholder: 'e.g. Sunrise HIIT'
    }, {
      label: 'Coach',
      name: 'c',
      type: 'select',
      options: ['Coach Bisi', 'Coach Femi', 'Coach Tobi', 'Coach Ada'],
      half: true
    }, {
      label: 'Capacity',
      name: 'cap',
      placeholder: '20',
      half: true
    }, {
      label: 'Day',
      name: 'day',
      type: 'select',
      options: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      half: true
    }, {
      label: 'Time',
      name: 't',
      type: 'time',
      half: true
    }], 'Schedule it', 'Class scheduled');
    if (/\bplan|pricing|price\b/.test(l)) return base('New plan', 'tag', [{
      label: 'Plan name',
      name: 'n',
      placeholder: 'e.g. Student'
    }, {
      label: 'Price',
      name: 'price',
      type: 'naira',
      placeholder: '13,999',
      half: true
    }, {
      label: 'Interval',
      name: 'iv',
      type: 'select',
      options: ['Monthly', 'Quarterly', 'Annual', 'Day pass'],
      half: true
    }, {
      label: 'Perks',
      name: 'perks',
      type: 'textarea',
      placeholder: 'What members get…'
    }], 'Create plan', 'Plan created');
    if (/\bstaff|team|instructor|coach\b/.test(l)) return base('Invite staff', 'user-cog', [{
      label: 'Full name',
      name: 'n',
      placeholder: 'e.g. Deborah A.'
    }, {
      label: 'Role',
      name: 'role',
      type: 'select',
      options: ['Front desk', 'Instructor', 'Manager', 'Accountant'],
      half: true
    }, {
      label: 'Phone',
      name: 'p',
      placeholder: '0801 234 5678',
      half: true
    }, {
      label: 'Email',
      name: 'e',
      placeholder: 'name@mail.com'
    }], 'Send invite', 'Invite sent');
    if (/\bgym\b/.test(l)) return base('Onboard a gym', 'building-2', [{
      label: 'Gym name',
      name: 'n',
      placeholder: 'e.g. Lekki Fitness'
    }, {
      label: 'Owner',
      name: 'o',
      placeholder: 'Full name',
      half: true
    }, {
      label: 'City',
      name: 'city',
      type: 'select',
      options: ['Lagos', 'Abuja', 'Port Harcourt', 'Ibadan', 'Kano'],
      half: true
    }, {
      label: 'Subdomain',
      name: 'sub',
      placeholder: 'lekkifitness',
      half: true
    }, {
      label: 'Plan',
      name: 'plan',
      type: 'select',
      options: ['Starter', 'Growth', 'Scale'],
      half: true
    }], 'Onboard gym', 'Gym onboarded');
    if (/\bticket|support\b/.test(l)) return base('New ticket', 'life-buoy', [{
      label: 'Subject',
      name: 's',
      placeholder: 'Short summary'
    }, {
      label: 'Gym',
      name: 'g',
      type: 'select',
      options: ['Powerhouse Fitness', 'Apex Arena', 'FitHub Abuja'],
      half: true
    }, {
      label: 'Priority',
      name: 'pr',
      type: 'select',
      options: ['Low', 'Normal', 'High', 'Urgent'],
      half: true
    }, {
      label: 'Details',
      name: 'd',
      type: 'textarea',
      placeholder: 'Describe the issue…'
    }], 'Open ticket', 'Ticket opened');
    if (/\bissue|equipment|machine|maintenance|fault\b/.test(l)) return base('Log an issue', 'wrench', [{
      label: 'Item',
      name: 'i',
      placeholder: 'e.g. Treadmill #4'
    }, {
      label: 'Zone',
      name: 'z',
      type: 'select',
      options: ['Weights floor', 'Cardio zone', 'Studio A', 'Locker room'],
      half: true
    }, {
      label: 'Severity',
      name: 'sev',
      type: 'select',
      options: ['Low', 'Medium', 'High'],
      half: true
    }, {
      label: 'Problem',
      name: 'p',
      type: 'textarea',
      placeholder: 'What\u2019s wrong?'
    }], 'Log issue', 'Issue logged');
    if (/\bclient\b/.test(l)) return base('Add PT client', 'dumbbell', [{
      label: 'Full name',
      name: 'n',
      placeholder: 'e.g. Ada B.'
    }, {
      label: 'Sessions',
      name: 's',
      placeholder: '6',
      half: true
    }, {
      label: 'Focus',
      name: 'f',
      type: 'select',
      options: ['Strength', 'Weight loss', 'Mobility', 'General'],
      half: true
    }, {
      label: 'First session',
      name: 'd',
      type: 'date'
    }], 'Add client', 'Client added');
    if (/\bcard|payment method\b/.test(l)) return base('Add payment method', 'credit-card', [{
      label: 'Card number',
      name: 'c',
      placeholder: '0000 0000 0000 0000'
    }, {
      label: 'Expiry',
      name: 'ex',
      placeholder: 'MM/YY',
      half: true
    }, {
      label: 'CVV',
      name: 'cv',
      placeholder: '123',
      half: true
    }], 'Add card', 'Card added');
    if (/\breminder|campaign|broadcast\b/.test(l)) return base('New reminder', 'bell', [{
      label: 'Audience',
      name: 'a',
      type: 'select',
      options: ['Expiring members', 'Expired members', 'All active', 'Class bookings']
    }, {
      label: 'Channel',
      name: 'ch',
      type: 'select',
      options: ['WhatsApp', 'SMS', 'Email'],
      half: true
    }, {
      label: 'Send',
      name: 'w',
      type: 'select',
      options: ['Now', 'Schedule'],
      half: true
    }, {
      label: 'Message',
      name: 'm',
      type: 'textarea',
      placeholder: 'Your message…'
    }], 'Save reminder', 'Reminder saved');
    return base(label, 'plus', [{
      label: 'Name',
      name: 'n',
      placeholder: 'Enter a name'
    }, {
      label: 'Notes',
      name: 'notes',
      type: 'textarea',
      placeholder: 'Optional'
    }], 'Save', 'Saved');
  }
  function openForm(label) {
    const s = formSpec(label);
    form({
      title: s.title,
      icon: s.icon,
      fields: s.fields,
      submitLabel: s.submitLabel,
      submitIcon: 'check',
      success: s.success,
      note: 'Prototype — nothing is saved.'
    });
  }
  function openExport(label) {
    const m = modal({
      title: label.replace(/\.$/, ''),
      subtitle: 'Generating your file…',
      icon: 'download',
      bodyHTML: `<div style="display:flex;align-items:center;gap:13px;padding:6px 0"><div class="gfui-spin"></div><span class="gfui-text" id="gfuiExpMsg">Preparing export…</span></div>`,
      actions: [{
        label: 'Close',
        kind: 'gf-btn-ghost'
      }]
    });
    setTimeout(() => {
      m.querySelector('.gfui-b').innerHTML = `<div class="gfui-done"><div class="ring"><i data-lucide="check"></i></div><p class="gfui-text">Your file is ready.</p></div>`;
      m.querySelector('.gfui-f').innerHTML = `<button class="gf-btn gf-btn-ghost" data-gfui-close>Close</button><button class="gf-btn gf-btn-primary" id="gfuiDl"><i data-lucide="download" style="width:16px;height:16px"></i> Download</button>`;
      m.querySelector('[data-gfui-close]').onclick = close;
      m.querySelector('#gfuiDl').onclick = () => {
        close();
        toast('Download started');
      };
      ic();
    }, 1100);
  }
  function openSupport(label) {
    modal({
      title: 'Help & support',
      subtitle: 'We usually reply within an hour',
      icon: 'life-buoy',
      bodyHTML: `<div class="group" style="margin:0"><a class="row" data-gfui-sup="WhatsApp"><span class="ic"><i data-lucide="message-circle"></i></span><div class="m"><strong>Chat on WhatsApp</strong><small>Fastest — +234 800 GYMFLOW</small></div><i data-lucide="chevron-right" class="chev"></i></a><a class="row" data-gfui-sup="Email"><span class="ic"><i data-lucide="mail"></i></span><div class="m"><strong>Email us</strong><small>help@gymflow.ng</small></div><i data-lucide="chevron-right" class="chev"></i></a><a class="row" data-gfui-sup="Call"><span class="ic"><i data-lucide="phone"></i></span><div class="m"><strong>Call support</strong><small>Mon–Sat, 8am–8pm</small></div><i data-lucide="chevron-right" class="chev"></i></a></div>`,
      onMount: m => m.querySelectorAll('[data-gfui-sup]').forEach(a => a.onclick = () => {
        close();
        toast(a.dataset.gfuiSup + ' — prototype');
      })
    });
  }
  function openDocs(label) {
    modal({
      title: 'Documents',
      subtitle: 'Waivers, receipts & policies',
      icon: 'file-text',
      bodyHTML: `<div class="group" style="margin:0">${['Membership waiver.pdf', 'Health declaration.pdf', 'Latest receipt.pdf'].map(d => `<a class="row" data-gfui-doc="${d}"><span class="ic"><i data-lucide="file-text"></i></span><div class="m"><strong>${d}</strong><small>Tap to download</small></div><i data-lucide="download" class="chev"></i></a>`).join('')}</div>`,
      onMount: m => m.querySelectorAll('[data-gfui-doc]').forEach(a => a.onclick = () => {
        close();
        toast('Downloading ' + a.dataset.gfuiDoc);
      })
    });
  }
  function detailDrawer(el, label) {
    const strong = el.querySelector('strong, b');
    const small = el.querySelector('small');
    const title = strong ? strong.textContent.trim() : label;
    const sub = small ? small.textContent.trim() : '';
    const badge = el.querySelector('.gf-badge');
    const av = el.querySelector('.gf-avatar');
    const letter = av ? av.textContent.trim().charAt(0) || title.charAt(0) : title.charAt(0).toUpperCase();
    drawer({
      title: title,
      subtitle: sub,
      bodyHTML: `<div class="gfui-id" style="margin-bottom:18px"><span class="gf-avatar gf-avatar-lg">${letter}</span><div><strong>${title}</strong><small>${sub || 'Detail'}</small></div></div>` + (badge ? `<div style="margin-bottom:16px">${badge.outerHTML}</div>` : '') + `<div class="gfui-rows"><div class="r"><span>Status</span><b>Active</b></div><div class="r"><span>Reference</span><b>GF-${Math.floor(1000 + Math.random() * 9000)}</b></div><div class="r"><span>Last update</span><b>Today</b></div></div>`,
      actions: [{
        label: 'Close',
        kind: 'gf-btn-ghost'
      }, {
        label: 'Message',
        kind: 'gf-btn-primary',
        icon: 'send',
        onClick: () => toast('Message sent — prototype')
      }]
    });
  }
  function route(el) {
    const label = clean(el);
    const l = label.toLowerCase();
    if (RX.danger.test(l)) return confirm({
      title: label,
      body: 'This can\u2019t be undone in a real account. Continue?',
      danger: true,
      confirmLabel: label.split(' ')[0],
      confirmIcon: 'trash-2',
      toast: label + ' — done'
    });
    if (/\bhelp|support|contact us\b/.test(l)) return openSupport(label);
    if (/\bwaiver|document|policy|invoice\b/.test(l)) return openDocs(label);
    if (RX.create.test(l)) return openForm(label);
    if (RX.exp.test(l)) return openExport(label);
    if (RX.send.test(l)) return confirm({
      title: label + '?',
      body: 'Send this now to the selected recipients?',
      confirmLabel: 'Send',
      confirmIcon: 'send',
      icon: 'send',
      toast: 'Sent — prototype'
    });
    if (RX.edit.test(l)) {
      const s = formSpec(label);
      return form({
        title: label,
        icon: 'pencil',
        fields: s.fields,
        submitLabel: 'Save changes',
        success: 'Saved'
      });
    }
    if (el.matches('.row, .lc') || RX.view.test(l)) return detailDrawer(el, label);
    return toast(label + ' — prototype');
  }

  // skip these — page-managed stateful controls / handled elsewhere
  const SKIP = '.bell, .theme-btn, [data-theme-toggle], #themeBtn, #admTheme, .viewtoggle, .gf-nav-item, .gf-chip, [data-tab], [data-dev], [data-f], [data-st], [data-d], [data-day], [data-i], [data-plan], [data-go], .cday, .day, .switch, .seg-ctrl button, .segtabs button';
  document.addEventListener('click', function (e) {
    const el = e.target.closest('a, .gf-btn, .icon-btn, .row, .lc, .gf-quick-action, .gf-dropdown-item');
    if (!el) return;
    if (el.closest('.gfui-bg, .gfui-drawer, .gfnp, .proto, .controls, .gf-sidebar, .rail, .tabbar')) return;
    if (el.matches(SKIP) || el.closest('.gf-table tbody tr')) return;
    // real navigation → let it through
    if (el.tagName === 'A') {
      const h = el.getAttribute('href');
      if (h && h !== '#' && h.slice(0, 11) !== 'javascript:') return;
    }
    if (el.onclick) return; // page already wired it
    if (el.tagName === 'BUTTON' && el.getAttribute('type') === 'submit' && el.closest('form')) return; // genuine form submit only
    e.preventDefault();
    e.stopPropagation();
    route(el);
  }, true);
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "revamp/ui.js", error: String((e && e.message) || e) }); }

// revamp/wire.js
try { (() => {
// Shared wiring: gives every nav item, dead link and unwired button feedback,
// and lets single-page sidebars switch their active state. Load after proto.js.
(function () {
  function gfToast(msg) {
    let t = document.getElementById('gfToast');
    if (!t) {
      t = document.createElement('div');
      t.id = 'gfToast';
      t.className = 'toast';
      t.innerHTML = '<i data-lucide="check-circle-2"></i><span></span>';
      document.body.appendChild(t);
    }
    t.querySelector('span').textContent = msg;
    if (window.lucide) lucide.createIcons();
    t.classList.add('show');
    clearTimeout(t._tm);
    t._tm = setTimeout(() => t.classList.remove('show'), 2000);
  }
  window.gfToast = gfToast;

  // Inject a "Mobile view" / "Desktop view" toggle when the page declares a counterpart.
  function injectViewToggle() {
    if (!document.body || document.querySelector('.viewtoggle')) return;
    const mobile = document.body.getAttribute('data-gf-mobile');
    const desktop = document.body.getAttribute('data-gf-desktop');
    const target = mobile || desktop;
    if (!target) return;
    const a = document.createElement('a');
    a.href = target;
    a.className = 'viewtoggle';
    a.innerHTML = '<i data-lucide="' + (mobile ? 'smartphone' : 'monitor') + '"></i><span>' + (mobile ? 'Mobile view' : 'Desktop view') + '</span>';
    document.body.appendChild(a);
    if (window.lucide) lucide.createIcons();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', injectViewToggle);else injectViewToggle();

  // Load the shared popup system + intent router (once per page).
  function injectUi() {
    if (document.getElementById('gfUiJs')) return;
    const s = document.createElement('script');
    s.id = 'gfUiJs';
    s.src = 'ui.js';
    document.body.appendChild(s);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', injectUi);else injectUi();
  function lbl(el) {
    const s = (el.getAttribute('aria-label') || el.title || el.textContent || '').trim().replace(/\s+/g, ' ');
    return s ? s.slice(0, 40) + ' — prototype' : 'Prototype action';
  }
  document.addEventListener('click', function (e) {
    // single-page sidebar nav items (no real href) → set active + toast
    const nav = e.target.closest('.gf-nav-item');
    if (nav) {
      const href = nav.getAttribute('href');
      if (!href || href === '#') {
        e.preventDefault();
        const par = nav.closest('.gf-sidebar-nav') || nav.parentElement;
        if (par) par.querySelectorAll('.gf-nav-item').forEach(x => x.classList.remove('active'));
        nav.classList.add('active');
        gfToast(lbl(nav));
        return;
      }
      return; // real link: let it navigate
    }
    // dead anchor links
    const a = e.target.closest('a[href="#"]');
    if (a) {
      e.preventDefault();
      gfToast(lbl(a));
      return;
    }
    // unwired buttons (skip ones with their own handler / real nav / submit)
    const b = e.target.closest('.gf-btn, .icon-btn');
    if (b && !b.onclick) {
      if (b.tagName === 'A') {
        const h = b.getAttribute('href');
        if (h && h !== '#') return;
      }
      if (b.type === 'submit') return;
      gfToast(lbl(b));
    }
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "revamp/wire.js", error: String((e && e.message) || e) }); }

__ds_ns.AboutPage = __ds_scope.AboutPage;

__ds_ns.FeaturesPage = __ds_scope.FeaturesPage;

__ds_ns.HomePage = __ds_scope.HomePage;

__ds_ns.PricingPage = __ds_scope.PricingPage;

__ds_ns.AdminShell = __ds_scope.AdminShell;

__ds_ns.MarketingFooter = __ds_scope.MarketingFooter;

__ds_ns.MarketingNav = __ds_scope.MarketingNav;

__ds_ns.FeatureCard = __ds_scope.FeatureCard;

__ds_ns.Step = __ds_scope.Step;

__ds_ns.Testimonial = __ds_scope.Testimonial;

__ds_ns.Faq = __ds_scope.Faq;

})();
